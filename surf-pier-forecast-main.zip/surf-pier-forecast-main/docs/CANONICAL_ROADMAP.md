# Surf & Pier Forecast canonical product roadmap

Last updated: 2026-08-17
Master tracker: [GitHub issue #318](https://github.com/ConnnnerDay/surf-pier-forecast/issues/318)

## Why this document exists

This is the durable contract for taking the broken Flask prototype to a
working online product. It is intentionally independent of any one AI chat.
Codex, Claude, a human developer, or another agent should be able to resume
work from this document and issue #318 without guessing what was agreed.

Several early sprint PRs were closed without being merged. Later PRs merged a
substantial `/v2`, but it uses a different frontend, authentication model,
database, request path, and deployment model. That merged code is valuable
implementation evidence; it is not permission to silently change the product
contract.

## Source-of-truth order

When sources disagree, use this order:

1. Explicit decisions in this document and master issue #318.
2. A later decision recorded in a merged decision-record PR and linked from
   issue #318.
3. Merged code and tests on `main`.
4. Closed or open PRs, archived plans, and previous AI conversations.

Changing a canonical decision requires a small decision-record PR and explicit
user approval. Updating code alone does not change the decision.

## Product contract

- Audience: recreational US surf and pier anglers — a public, general-
  audience product intended to grow beyond a private circle, not a personal
  or friends-only tool. Plan for real (if initially modest) public traffic.
- Experience: polished, marine-utility, mobile-first installable web product.
  Minimum support target: the latest two versions of Chrome, Safari, Firefox,
  and Edge, on both mobile and desktop. No legacy-browser support.
- Coverage: any valid US coastal coordinate, including Atlantic, Gulf,
  Pacific, Alaska, and Hawaii, at v1 launch — coverage breadth is part of the
  pitch and is not phased in regionally.
- Access: an account is required for the core forecast experience.
- First-run success: a new user can register, choose a coastal point, and
  quickly understand whether and when to fish.
- Reliability: a single upstream provider failure must not blank the forecast.
- Integrity: missing observations are never turned into invented measurements.
- Result vocabulary: `fresh`, `stale`, `partial`, and `unavailable` have
  documented, testable meanings.
- Data minimization: save resolved location identifiers and appropriately
  rounded coordinates rather than unnecessary precise location history.
- Cost: near-free is a target, but not at the expense of minute-long cold
  starts or disposable production data. Observability/analytics tooling
  should default to pragmatic, free-tier services rather than a named vendor
  commitment.
- Business model: v1 ships free. Don't build payment infrastructure or
  subscription legal pages yet, but don't foreclose a future low-price
  (~$1/month) subscription tier either. The expansion-decision sprints
  (61-63) own the actual call.
- Trust and liability: any fishing-regulations or legal-catch guidance must
  carry a clear "informational only — verify with official sources"
  disclaimer before it ships publicly. Treat the legacy 851-species/
  regulations dataset as provisional; the long-term intent is to source
  regulations data from official state/NOAA feeds rather than trust the
  inherited dataset indefinitely.
- Support: a minimal in-app feedback mechanism is part of the launch-
  readiness bar (sprint 50), not an optional add-on.
- Legacy app: the current self-hosted Flask app is retired outright,
  effective immediately, not kept running in parallel during the rewrite. No
  live accounts or catch data exist on it worth migrating.

### Deferred until production evidence supports them

Payments, advertising, native clients, social features, catch logging, live
cameras, notifications, passkeys, OAuth, a full regulations product, and the
full 851-species experience are not v1 launch requirements. Self-service data
export and account deletion (sprint 45) are the one carve-out from this list:
required at v1 launch, not deferred, because this is a public product
handling real accounts.

## Product decisions on record (2026-08-17)

These were made directly by the product owner (not inferred) and refine the
product contract above. Per the source-of-truth order, explicit decisions
recorded in this document are binding until superseded by a later decision
record; they do not reopen or contradict R0.

### Strategy and audience

- **Audience and scale.** Public, general-audience product intended to grow
  beyond a private circle. Plan for real public traffic, not a handful of
  known users.
- **Business model.** v1 is free, no payment processor or billing UI yet. The
  long-term intent is a ~$1/month subscription tier once usage justifies it;
  keep the account model tier-friendly without building billing now.
- **Growth.** No hard launch deadline. Growth starts organic (SEO, shareable
  forecast pages, word of mouth), but the product owner is willing to invest
  in paid acquisition or other growth spend later — keep that option live in
  the expansion-decision sprints.
- **Timeline.** No hard deadline; work the gates/sprints at a sustainable
  pace rather than compressing for speed.
- **Hosting budget.** No fixed ceiling stated, but the ~$1/month target price
  implies real cost-consciousness. Default to free/low-cost tiers where
  reasonable and surface costs as they come up.

### Legacy app

- The current self-hosted Flask app is retired outright, effective
  immediately. No real accounts or catch-log data exist on it worth
  migrating or communicating a sunset to.
- The merged `/v2` React/Vite prototype remains reference material for the R1
  reconciliation audit only, per the existing canonical contract.

### Trust, legal, and data sourcing

- Any regulations/legal-catch guidance must carry a clear "informational
  only — verify with official sources" disclaimer before shipping publicly.
  Hard requirement, not a nice-to-have.
- The legacy 851-species/regulations dataset is provisional. Long-term intent
  is to source regulations data from official state/NOAA feeds rather than
  trust the inherited hand-built dataset indefinitely; acceptable as a
  stopgap only with the disclaimer above.
- Self-service data export and account deletion (sprint 45) are required at
  v1 launch, not deferred.

### Product surface decisions

- **Branding.** Name, domain, and visual identity are all still open. Sprint
  27 needs an explicit branding decision as a prerequisite. No brainstorming
  has happened yet — deliberately deferred to a later pass.
- **Device/browser support.** Latest two versions of Chrome, Safari, Firefox,
  Edge; mobile and desktop; no legacy-browser support.
- **Offline/PWA depth.** Full app-shell navigation should work offline with
  graceful degradation (sprint 38), not just "show the last cached forecast."
- **Abuse hardening.** Public registration needs bot/CAPTCHA defense as a v1
  requirement (sprints 28/44), not just rate limiting and email verification.
- **Support channel.** A minimal in-app feedback widget is part of the
  launch-readiness bar (sprint 50), not a post-launch add-on.
- **Feature priority after v1.** None of the currently-deferred features
  (notifications, catch logging, OAuth/passkeys, full species DB, full
  regulations product, social, native apps, live cameras) are prioritized
  over nailing the core forecast experience first.
- **Beta recruiting (sprint 51).** Recruit the initial cohort through the
  product owner's personal network and local surf/pier fishing communities,
  not a fully public open beta.
- **Observability/analytics tooling (sprints 41-43).** No named vendor
  preference — choose pragmatic, free-tier-friendly tools rather than
  spending a sprint deciding between options.
- **Testing/CI rigor.** Keep the roadmap's definition-of-done as written in
  full (accessibility passes, Lighthouse budgets, load tests, security
  hardening) — not scaled back, since the audience is public, not private.

### Team and process

- Sole human reviewer/approver for the foreseeable future, with AI agents
  doing implementation work under the existing AI-review-plus-human-approval
  gate. Document the PR/roadmap process well enough that a future
  collaborator could onboard without extra chat context, since collaborators
  may be added later.

## Product decisions on record (2026-08-17, round 2)

- **Positioning.** "Surfline, but for fishing" — a polished conditions/
  forecast product purpose-built around "should I fish right now," not a
  general-purpose fishing social app.
- **Go/no-go presentation.** Lead the dashboard with a simple traffic-light
  style (color + short label); numeric score and narrative detail are
  supporting, expandable information, not the headline.
- **Voice.** Clean, utility-first, data-forward. Closer to a marine
  instrument than a lifestyle/social brand — not casual angler-buddy copy.
- **Naming.** "Surf & Pier Forecast" is a placeholder only. The product name
  itself, not just the visual identity, is open to a full rename during the
  branding decision ahead of sprint 27.
- **Paid-tier mechanism (informative, not yet built).** The most likely
  ~$1/month lever is saved-location count: free tier is capped at **1**
  saved (home) location; more locations is the paid unlock. Sprint 37
  (saved locations) should build the ownership model so a cap/limit field is
  natural to add later, without committing to billing now.
- **Species photos.** Defer together with the rest of the species-scoring
  feature — not worth decoupling for an early v1 win.
- **Freshness TTL.** Keep the legacy app's 4-hour cache window as the v1
  target for sprint 24 (snapshot caching); revisit only if real usage shows
  it's wrong.
- **Shareable forecast links.** Pull forward as a v1-required feature (not
  just "later in phase 4"), since public non-personal forecast pages
  (sprint 49) are direct organic-growth/SEO surface and growth is a stated
  priority.
- **Internationalization.** English-only content at v1, but build content/
  copy in an i18n-ready structure (externalized strings, no hard-coded
  English in logic) from the start, so Spanish-language support — relevant
  given Gulf Coast and other US coastal Hispanic angling communities — isn't
  a rewrite later. Actual Spanish translation stays out of v1 scope.
- **Data-quality validation.** No personal regional expertise to anchor
  testing on; rely on official upstream sources and general QA across all
  launched coasts equally rather than a single home-region deep check.
- **Alert channel (forward-looking).** Whenever notifications/alerts are
  eventually built, prioritize web push over email, fitting the installable
  mobile-first PWA product — this doesn't change notifications' deferred
  status for v1.

## Product decisions on record (2026-08-17, round 3)

- **What's actually broken today.** The product owner rates the current app
  as roughly equally broken across performance/reliability, UI/UX, and data
  quality — no single dimension is the standout problem. R1's reconciliation
  audit and the phase 1-3 sprints should treat this as a full rebuild, not a
  targeted patch of one weak layer.
- **Open source.** Not an active decision. Repo visibility (public vs.
  eventually private) stays as-is; revisit only if it becomes relevant later
  rather than deciding preemptively.
- **Success target.** Directional goal for 6-12 months post-launch: low
  thousands of active users — meaningful public traction, enough to
  seriously validate the ~$1/month tier as real revenue, not just a proof of
  concept. This is a directional target for calibrating sprints 57-59, not a
  committed metric.

## Product decisions on record (2026-08-31, round 4)

- **Branding — the name is Saltline.** Resolves sprint 27's
  long-standing open item: "Surf & Pier Forecast" was always a
  placeholder, not a decision. The product owner directed a full
  visual rebrand in a Surfline-style outdoor/adventure direction
  (bright/coastal, not the darker, moodier extreme-sports register),
  reviewed as a concept canvas (name options, palette, type, key-screen
  mockups) before implementation. `docs/product-definition.md`'s
  opening line still names the old placeholder verbatim, per how this
  document handles the doc it was recovered from (see sprint 2's row)
  — this entry is the correction of record, not a rewrite of that file.
  Real photography for the product doesn't exist yet; hero imagery is
  an explicitly labeled placeholder pattern, never an AI-generated
  stand-in, per direct instruction on that point.

## Canonical technical contract

| Area | Required product architecture |
|---|---|
| Repository | Monorepo with `apps/web`, `apps/api`, and generated shared OpenAPI schemas |
| Web | Next.js, mobile-first, deployed to Vercel |
| Browser path | Browser calls the Next.js backend-for-frontend only |
| Internal path | Next.js authenticates the user and signs internal FastAPI requests |
| API | FastAPI with versioned `/v1` endpoints, deployed on an always-on entry Render service |
| Authentication | Better Auth email/password, verification, reset, secure HTTP-only cookies, PostgreSQL sessions |
| Database | Fresh PostgreSQL on pooled Neon; no legacy account or catch-data migration |
| Background work | No Redis and no job queue in v1 |
| Forecast core | Port Python logic only after characterization tests capture defensible behavior |
| Availability | Bounded provider calls, independent source results, immutable snapshots, documented stale fallback |

### Required API surface

- `GET /v1/locations/search?q=`
- `POST /v1/locations/resolve`
- `GET /v1/forecasts/{location_id}`
- `POST /v1/forecasts/{location_id}/refresh`
- `GET /v1/me/preferences`
- `PATCH /v1/me/preferences`
- `GET /health/live`
- `GET /health/ready`

The forecast envelope contains location, generated time, freshness, source
status, confidence, conditions, tides, hourly outlook, recommendations, and
structured warnings.

## Current repository reality

| Subsystem | Canonical | Merged `/v2` reality | Required disposition |
|---|---|---|---|
| Frontend | Next.js BFF | React/Vite PWA calling the API | Audit reusable UI; establish Next.js path |
| Authentication | Better Auth cookie sessions | Custom JWT plus OAuth/passkeys/2FA | Replace core auth; defer non-v1 extras |
| Database | PostgreSQL/Neon | SQLite-oriented implementation | Design and migrate to fresh PostgreSQL |
| Deployment | Vercel + Render + Neon | Self-host/placeholder assumptions | Add canonical environments and runbooks |
| API | Versioned FastAPI | FastAPI prototype exists | Keep or adapt only after contract audit |
| Providers and scoring | Characterized Python core | Large legacy port exists | Keep candidates that pass fixture-based tests |
| End-to-end tests | Deterministic launch journey | Some tests depend on live upstreams | Replace live CI dependence with controlled fixtures |

Closed PRs [#309](https://github.com/ConnnnerDay/surf-pier-forecast/pull/309)
through [#313](https://github.com/ConnnnerDay/surf-pier-forecast/pull/313)
are unmerged reference material. Merged PRs
[#314](https://github.com/ConnnnerDay/surf-pier-forecast/pull/314) through
[#317](https://github.com/ConnnnerDay/surf-pier-forecast/pull/317) explain the
current `/v2` code, but do not override this contract.

## Recovery gates (must happen before new features)

| Gate | Outcome | Acceptance evidence | State |
|---|---|---|---|
| R0 | Durable canonical roadmap and cross-agent handoff | This document, `AGENTS.md`, Claude warning, master issue, merged PR | Complete — merged in PR #319 |
| R1 | Reconciliation audit | Every `/v2` route, module, schema, feature, and test mapped to keep/adapt/replace/defer with reasons and owning future sprint | Complete — merged in PR #322 |
| R2 | Truthful deterministic CI baseline | Exact current commands recorded; live-provider tests removed from required CI; failures classified as regression or known debt | Complete — merged in PR #323 |
| R3 | One canonical application path | Next.js/FastAPI/PostgreSQL skeleton is the named path; duplicate prototypes are clearly archived/reference-only; local smoke path is documented | Complete — merged in PR #324 |

No gate may be marked complete until its PR is merged to `main` and linked in
issue #318.

**All recovery gates (R0-R3) are complete.** Numbered product sprints
resume — see the live checkpoint below for the exact next action.

## Sprint ledger

Status meanings:

- **Not accepted**: no merged evidence satisfies the canonical outcome.
- **Candidate in `/v2`**: code may help, but R1 must map it and the numbered
  sprint still needs canonical acceptance evidence.
- **Deferred**: deliberately outside the v1 launch contract.
- **Complete**: only a merged PR with linked checks can earn this state.

None of the numbered sprints below is currently marked complete. That is
deliberately conservative: closed PR work and divergent merged code are inputs
to reconciliation, not proof that the agreed outcome passed.

### Phase 1 — Establish the rewrite

| Sprint | Outcome | Acceptance focus | Current state |
|---:|---|---|---|
| 1 | Repository baseline | Reproducible legacy audit, routes, sources, failures, reusable modules | **Complete** — `docs/baseline-audit.md` (this PR), recovered verbatim from closed PR #309 and reviewed for conflicts with later decisions; none found |
| 2 | Product definition | Journey, non-goals, metrics, vocabulary, attribution | **Complete** — `docs/product-definition.md` (this PR), recovered verbatim from closed PR #310; refined, not contradicted, by the later "Product decisions on record" sections above |
| 3 | Architecture decision | Boundaries, request path, records, hosting, data lifecycle | **Complete** — `docs/architecture.md` (this PR), recovered verbatim from closed PR #311 except one reconciliation note: its `pnpm`/`uv` tooling choice is superseded by the already-merged `npm`/`pip` tooling in `apps/web`/`apps/api` |
| 4 | Monorepo scaffold | Clean Next.js/FastAPI install, build, and smoke test | **Complete** — `apps/web`/`apps/api` skeletons (PR #324) plus their CI build/smoke-test evidence (PR #326) |
| 5 | Local developer workflow | One documented setup/run/check path from a fresh machine | **Complete** — `apps/setup.sh` and `apps/check.sh` (PR #327), verified end-to-end from a genuinely clean state (no `.venv`/`node_modules` present beforehand) |
| 6 | Quality gates | Frontend and Python lint, type, test, and intentionally failing proof | **Complete** — real lint/type/test checks for `apps/` (PR #326), plus the intentionally-failing proof (PR #329): a scratch branch that deliberately broke all five `apps-ci.yml` checks, pushed to observe a real red CI run. It was briefly and accidentally merged (see `docs/SPRINT_6_CI_PROOF.md`'s "Incident" section) and reverted in PR #330 — doesn't invalidate the proof itself, but is the direct motivation for sprint 7 |
| 7 | PR governance | Sprint/PR templates, ownership, dependency policy, AI review contract | **Complete** — `.github/pull_request_template.md` and `docs/PR_GOVERNANCE.md` (PR #331), consolidating ownership, one-PR-per-sprint policy, dependency policy, the AI review contract, and a branch-hygiene rule written directly from the sprint-6 incident |
| 8 | CI foundation | Checks, secret scan, dependency audit, builds | **Complete** — `apps/` build/lint/type/test checks (PR #326); this PR adds `.github/workflows/security.yml`: repo-wide gitleaks secret scan (with a documented `.gitleaksignore` for two verified false positives) and `pip-audit`/`npm audit` dependency checks for `apps/api`/`apps/web` (both currently clean) |
| 9 | Preview environments | Isolated web/API previews with URL and curl evidence | Not accepted |
| 10 | Production skeleton | Vercel, always-on Render, pooled Neon connectivity and environment separation | Not accepted |

### Phase 2 — Build a trustworthy forecast core

| Sprint | Outcome | Acceptance focus | Current state |
|---:|---|---|---|
| 11 | Canonical domain model | Typed models, schema snapshots, serialization round trips | **Complete** — `apps/api/app/domain/models.py` (fresh Pydantic models per `docs/architecture.md`'s ADR-003, not ported from `v2/backend/app/schemas/`, which are auth-coupled DTOs per `docs/R1_RECONCILIATION_AUDIT.md`); schema-snapshot + round-trip tests in `apps/api/tests/test_domain_models.py`, drift-detection verified locally before commit |
| 12 | HTTP client policy | Timeouts, bounded retries, user agent, size limit, structured errors | **Complete** — `apps/api/app/infra/http_client.py` (`BoundedHTTPClient` per `docs/architecture.md`'s ADR-003, provider-agnostic); `apps/api/tests/test_http_client.py` covers success, retries, retry exhaustion, no-retry-on-4xx, timeouts, connection errors, and oversized responses via `httpx.MockTransport` |
| 13 | NWS adapter | Typed weather, wind, alerts, and grid contract fixtures | **Partially complete** — `apps/api/app/providers/nws.py`: marine-zone wind/wave/direction parsing and fetch, point/state active-alerts parsing and fetch, **plus the gridpoint wind fallback** (`fetch_gridpoint_wind`/`parse_gridpoint_wind`, wired into `app/domain/assembly.py` as a last-resort wind source, fetched only when both primary wind sources fail), all behind `apps/api/tests/test_nws_provider.py`/`test_assembly.py` fixture tests. Current-weather observations (air temp, humidity, heat index, precipitation) remain deliberately deferred — nothing in the required `ForecastConditions` shape names them, so porting would be inventing product scope |
| 14 | NOAA CO-OPS adapter | Tide/water-temperature fixtures, missing values, DST | **Partially complete** — `apps/api/app/providers/noaa_coops.py`: water temperature and tide predictions, `zoneinfo`-based DST-safe timestamp parsing, missing-value/empty-row handling, **plus the CO-OPS wind fallback** (`fetch_coops_wind`, wired into `app/domain/assembly.py` as the second step of the last-resort wind chain, after marine-zone/buoy and before NWS gridpoint — the legacy priority order), all behind `apps/api/tests/test_noaa_coops_provider.py`/`test_assembly.py`. Currents, environmental metrics, and the tide-chart SVG helper remain deliberately deferred — nothing in the required `ForecastConditions` shape or product-definition's dashboard hierarchy names them |
| 15 | NDBC adapter | Buoy parsing, missing columns and markers | **Partially complete** — `apps/api/app/providers/ndbc.py`: wind/wave/pressure parsing from the fixed-width `realtime2` feed (`parse_realtime_text`) and fetch (`fetch_buoy_observation`), distinguishing missing columns from missing-value markers, behind `apps/api/tests/test_ndbc_provider.py`. `app/infra/http_client.py`'s `BoundedHTTPClient` gained `get_text` for this (NDBC is plain text, not JSON). Pressure-trend/fishing-impact narrative deliberately deferred to the scoring sprint (35) — see module docstring |
| 16 | Astronomy adapter | Pure deterministic coast/season/timezone tests | **Complete** — `apps/api/app/providers/astronomy.py`: sunrise/sunset, twilight, lunar details, and solunar periods, all pure math (no network). Typed timezone-aware `datetime`s instead of formatted strings; enums for moon phase/rating. `apps/api/tests/test_astronomy_provider.py` covers Atlantic/Pacific coasts, summer/winter seasons, a non-DST timezone, and polar-latitude clamping |
| 17 | Station catalog | Provenance, timestamps, idempotent refresh | **Complete** — `apps/api/app/providers/stations.py`: CO-OPS tide/water-temp and NDBC catalog fetch (degrades to `[]`, metadata not a reading), pure nearest-station distance ranking, and `StationCatalogCache` — an explicit, injectable-clock, idempotent TTL cache, tested without sleeping in `apps/api/tests/test_stations_provider.py` |
| 18 | Coastal coordinate validation | Inland/out-of-range rejection and all-coast boundaries | **Complete** (using only sprint 17's inputs — see the sprint's checkpoint entry for the curated-location fallback deferred to sprint 19) — `apps/api/app/providers/coastal_bounds.py`: `is_valid_coordinate`, `classify_coast_region` (bounding boxes for Atlantic/Gulf/Pacific/Alaska/Hawaii), and `gate_coastal_point` (the real inland-rejection mechanism, ported from `locations.py`'s `_DYN_GATE_MILES`), tested in `apps/api/tests/test_coastal_bounds.py` |
| 19 | Location resolution | Timezone, zone, tide/temp station and buoy golden tests | **Complete** — `apps/api/app/providers/locations.py`: curated 101-spot dataset (`app/data/coastal_locations.json`/`water_temps.json`, `ast.literal_eval`-extracted from the legacy source, a documented mechanical move), `find_nearest_locations`, `timezone_for_point`, `resolve_dynamic_location` (composes sprint 17's station catalogs), golden-tested in `apps/api/tests/test_locations_provider.py` against Montauk NY/Wrightsville Beach NC/Poipu HI |
| 20 | Observation normalization | Canonical units/times with raw provenance retained | **Complete** — `apps/api/app/domain/normalize.py`: wraps sprints 13-15's provider outputs into `Observation` (canonical `kt`/`ft`/`degF`/`mb` units, provider/station/observed_at retained); NWS forecast ranges become an `ObservationRange` (paired low/high) rather than a collapsed value; astronomy and categorical fields (wind direction) deliberately not wrapped; tested in `apps/api/tests/test_normalize.py` |
| 21 | Forecast assembly | Independent sources and every present/absent matrix | **Complete** — `apps/api/app/domain/assembly.py`: concurrently fans out to NWS/NOAA CO-OPS/NDBC + astronomy, assembles `ForecastEnvelope` and designs `conditions`; water-temperature fallback-to-monthly-average finally lands (deferred since sprint 14); `apps/api/tests/test_assembly.py` exercises all 8 present/absent combinations of the 3 fallible sources |
| 22 | Forecast scoring | Defensible stable score components with explanations | **Complete** — `apps/api/app/domain/scoring.py`: `score_conditions`, the 0-100 go/no-go index ported from `domain/forecast.py`, scores wind/wave/direction/water-temp/dawn-dusk/solunar factors with a sorted, plain-language summary; deliberately decoupled from sprint 21's `ForecastConditions` (takes a pre-reconciled `wind_range`/`wave_range`); tide, fishing-type/preference, and water-quality bonuses deliberately deferred (sprints 34/36, still-open product question); tested in `apps/api/tests/test_scoring.py` |
| 23 | Confidence model | Predictable degradation by availability, distance, age, fallback | **Complete** — `apps/api/app/domain/confidence.py`: `assess_confidence`, a 100-point four-factor score (source coverage, observation age, station distance, fallback use) with no legacy precedent, replacing sprint 21's interim liveness-only stub; each degrading factor reports an independent reason code; tested in `apps/api/tests/test_confidence.py` |
| 24 | Snapshot caching | Fresh/stale hit, miss, expiry, fallback, concurrency; target 4-hour freshness window, matching legacy cadence | **Complete** — `apps/api/app/infra/snapshot_cache.py`: `SnapshotCache[T]`, an injectable-clock, per-key, single-flight in-memory cache; `fresh_ttl_seconds` defaults to 4h matching legacy cadence, `stale_ttl_seconds` + fallback-on-fetch-failure are new (no legacy precedent); tested in `apps/api/tests/test_snapshot_cache.py` |
| 25 | Versioned API | Required endpoints, OpenAPI contract and breaking-change guard | **Complete** — `apps/api/app/api/v1/{locations,forecasts}.py`: 4 of 6 required endpoints (`GET`/`PATCH /v1/me/preferences` deliberately deferred — need Better Auth + Postgres, neither exists yet); `app/api/deps.py`'s `AppState` (lifespan-managed `BoundedHTTPClient` + station-catalog caches) backs both routers; `tests/openapi_snapshot.json` + `scripts/generate_openapi_snapshot.py` is the breaking-change guard, mirroring sprint 11's schema-snapshot pattern; verified against a real running `uvicorn` server, not just `TestClient`; tested in `apps/api/tests/test_locations_router.py`/`test_forecasts_router.py`/`test_openapi_snapshot.py` |
| 26 | Performance budget | Bounded parallel calls, no duplicates, warm p95 under 750 ms | **Complete** — `BoundedHTTPClient` now sets explicit `httpx.Limits` (bounded parallel calls); `tests/test_performance_budget.py` proves no-duplicates under real concurrent HTTP requests (`asyncio.gather` + `httpx.ASGITransport`) and measures warm p95 ≈ 2.8ms against the 750ms budget. Cold-path latency against live upstreams is untestable in this sandboxed CI environment — not part of this sprint's stated bar, but flagged as open evidence for whenever this runs with live network access |

### Phase 3 — Create the mobile product

| Sprint | Outcome | Acceptance focus | Current state |
|---:|---|---|---|
| 27 | Design system | Gallery at phone/desktop widths and accessible primitives; branding decided first (name included, not just visual identity — "Surf & Pier Forecast" is a placeholder); clean/utility-first tone, Surfline-for-fishing positioning | **Complete** — **the branding decision is made: "Saltline."** Product owner directed a full visual rebrand in a Surfline-style outdoor/adventure direction (bright/coastal, not the darker moodier extreme-sports register), open to a new name; a concept canvas (name options, palette, type, key-screen mockups) was reviewed before implementation. Shipped in `apps/web`: `app/globals.css`'s `@theme` tokens carry a new oklch-based coastal palette (light/dark, semantic go/marginal/no-go tokens tuned per-theme, not a naive inversion) and a Space Grotesk/Public Sans type pairing (loaded via a `<link>` in `app/layout.tsx`, not `next/font/google` — that API fetches font files at *build* time, which fails under restricted outbound network, this sandbox included; `next.config.ts`'s CSP gained the one deliberate external allowance for it). `app/components/ui/` (`Button`/`Card`/`Badge`/`Field`/`Container`) needed no code changes — the whole app repaints from the token change alone, proving out the sprint's own "real accessible primitives, not global CSS classes" bet. `app/page.tsx` is now a real landing page (hero, value props, popular-spots links to real curated locations — deliberately no fabricated verdict badges on them, the product's own Integrity rule); the former component gallery moved to `/design-system`. `app/icon.tsx`/`opengraph-image.tsx` carry the new Saltline logomark (a horizon line, sunrise arc, and wave — literally "where the tide meets the shore"). Real photography doesn't exist yet, so hero art is an explicitly-labeled placeholder pattern (`.ph-photo` in `globals.css`), never an AI-generated fake. Caught and fixed one real bug in the process: the brighter initial teal (`--color-primary`) cleared AA contrast as a button background but failed as bare text (`Button`'s "secondary" variant, eyebrow labels) — axe-core caught it at 3.6-3.8:1; fixed by computing real WCAG contrast ratios (canvas-rendered oklch → sRGB, not eyeballed) and choosing a lightness that clears 4.5:1 in both roles at once. Verified against two real running servers: a full `axe-core` sweep (5 pages × 2 viewports × 2 themes) plus the sprint-40 interactive combobox states, 0 violations; tap-target and route-table checks unaffected. **Follow-up layout pass** (same PR sequence): the first cut only re-themed existing layouts via the token change; a second pass actually reworked the forecast and search pages' composition to match the reviewed concept, not just their colors — the forecast page gained a real photo-hero band (`.ph-photo`, a back-to-search link, the location name overlaid) above `ForecastCard`; `BestWindowCallout` became a distinct coral-tinted (`--color-accent-tint`, added this pass) callout card with a clock icon instead of a plain text line; the conditions-summary/score-details block gained a `bg-bg` sunken-panel treatment inside the card; `LocationSearch`'s dropdown gained row dividers, a softer selected-row highlight (`--color-primary-tint`, also added this pass) instead of a solid fill, and a checkmark on the active option. Caught a second real contrast bug immediately via the same computed-ratio method: the new callout's "Best window" label at `text-accent` on `bg-accent-tint` measured 2.49:1 in light mode (badly failing AA) — fixed by using `text-text-muted` instead, matching the existing eyebrow-label color pattern elsewhere in the same component. Re-verified with the same full `axe-core` sweep, the interactive combobox states, the keyboard-only walkthrough, and tap-target checks — 0 violations, no regressions. i18n-ready string externalization (bundled into this sprint by R1's disposition) remains open, as does real photography (needs actual shot assets, not attempted here) |
| 28 | Authentication | Email/password lifecycle, session rotation, bot/CAPTCHA defense on registration, abuse tests | **Partially complete** — the standing blocker ("Better Auth + Postgres infrastructure decisions that don't exist yet") turned out narrower than it looked: `docs/architecture.md`'s ADR-005/ADR-006 only ever needed *a* PostgreSQL instance, not specifically the not-yet-provisioned Neon project (sprints 9/10 still own that credentials gap) — a real local Postgres 16 is available in this environment. Shipped in `apps/web`: `lib/auth.ts` — Better Auth, email/password, backed by a real Postgres `auth` schema via Better Auth's own `schemaName` option (qualifies every statement itself, not the connection's `search_path`), owned by a least-privilege `saltline_web` role with no grants on `public` or any future `forecast` schema, matching ADR-006's schema-per-concern split; `DATABASE_URL` is a real local connection string today, a connection-string change (not a code change) once pooled Neon exists. `scripts/migrate-auth-db.mts` applies Better Auth's own migration plan via `better-auth/db/migration`'s `getMigrations` directly rather than `@better-auth/cli` (that package pulls its own separately-vendored, older `better-auth` with several unpatched critical CVEs, all in OAuth/OIDC/magic-link/organization-plugin paths this app doesn't enable, but avoidable anyway since the CLI's own `migrate` command calls the same function). `lib/email.ts` sends verification/reset email via `nodemailer`, reusing CLAUDE.md's `SMTP_*` convention from the retired legacy app; `requireEmailVerification`/`sendOnSignUp` both follow whether SMTP is actually configured, the same "if unset, accounts auto-confirm and no emails are sent" behavior documented for that legacy app. Rate limiting (ADR-005's "separate rate limits" per action) via `rateLimit.customRules`, verified live rather than just configured: a clean-state run of 7 rapid `/sign-in/email` requests allowed exactly 5 before a 429, confirming the custom rule overrides Better Auth's own stricter built-in default for that path. `/register`/`/login`/`/forgot-password`/`/reset-password` pages and `AuthStatus` (the one session-dependent piece of the otherwise server-rendered `SiteHeader`) needed zero new primitives — `Field`/`Card`/`Button` repainted correctly, the same payoff sprint 27's rebrand already proved. Adding `AuthStatus` crowded the header at phone width and exposed a real pre-existing text-wrap bug, fixed with `whitespace-nowrap`. CSRF, secure/HttpOnly cookies, and session rotation are Better Auth defaults, satisfying that part of the ADR with no extra config. Verified end-to-end against real running `next start`/local-Postgres servers: registered a real account, confirmed the session survives a full page reload, signed out, logged back in, and confirmed a wrong password is rejected with a real 401 and on-page error; a fresh `axe-core` sweep across all four new pages × 2 themes found 0 violations. **Not attempted**: bot/CAPTCHA defense on registration needs a real third-party provider (Cloudflare Turnstile or hCaptcha) and a site key/secret this session has no credentials for — flagged the same way sprints 9/10's Vercel/Render/Neon credentials were flagged, not guessed at. Also caught and patched, while adding this sprint's dependencies: two pre-existing `npm audit` findings (`next`'s critical unauthenticated-RCE advisory and its transitive `sharp`'s high libheif issue), both already present before this sprint touched either — patch-level bumps inside the existing semver range, `package.json` itself unchanged. Account-required routing (sprint 29), onboarding (sprint 30), and threading a real signed-in user ID into `lib/internal-api-client.ts`'s calls to apps/api (that file's own docstring already anticipated this sprint) stay separate sprints' jobs — nothing in this PR gates any existing page behind a session |
| 29 | Account-required routing | Public exceptions and authorization/redirect tests | **Complete** — `docs/product-definition.md`'s "account is required for the core forecast experience"/"core browsing requires a verified account" read literally: `app/locations/page.tsx` (search) and `app/forecast/[locationId]/page.tsx` (per-location lookup) both check the session server-side (`auth.api.getSession()`, same pattern `app/preferences/page.tsx` already used) and `redirect('/login?next=<path>')` before any fetch or client code runs for an anonymous visitor — a crawler or curl gets a real (RSC-streamed, not a plain top-level 307, since both routes have a `loading.tsx` sibling — verified this actually works via a real browser, not just assumed from the HTTP status code, after an early false read of a raw `curl` check that couldn't see the streamed redirect instruction) redirect, never the real content. `app/api/locations/search/route.ts` (the BFF proxy `app/locations/page.tsx` calls) gained its own independent session check — the page-level redirect keeps a browser from reaching the search form, but doesn't stop a direct `fetch()` call to that route, so it needed its own 401. `app/login/page.tsx`/`app/register/page.tsx` gained a `?next=` parameter (`lib/safe-redirect.ts` guards against the classic `//evil.example.com` open-redirect trick) so a bounced visitor lands back where they were headed, not always `/`, threaded through the "sign up instead"/"log in instead" cross-links too. The public exception this sprint required — sprint 49's public, non-personalized share page, previously living at these same `/forecast/[locationId]` URLs — moved to its own route, `app/share/[locationId]/page.tsx`, rather than being dropped; see sprint 49's updated row for that split's full account. `app/robots.ts` gained the real `Disallow` rules that row's "private dashboards" half had been waiting on. Verified end-to-end against real running `next start`/`uvicorn`/local-Postgres servers: anonymous visits to both gated routes redirect to `/login?next=...`; registering with `?next=/locations` set lands back on `/locations`, not `/`; while signed in, both routes work normally including a real search→select→forecast walkthrough; signing out and revisiting the forecast page redirects again. `axe-core` 0 violations across the share page, `/login?next=...`, and `/register?next=...`, light/dark. `npm run lint`/`build` clean |
| 30 | Onboarding shell | Mobile recording from registration to dashboard | Candidate in `/v2` |
| 31 | Location search | Text, device, map, station preview, denial/ambiguity tests | **Partially complete** — text search: `apps/web/app/components/location-search.tsx` (a hand-rolled WAI-ARIA combobox, no dependency) calls `apps/web/app/api/locations/search/route.ts` (a BFF Route Handler proxying apps/api's `GET /v1/locations/search` through the signed internal path — the browser never calls apps/api directly, ADR-004), demonstrated on `apps/web/app/locations/page.tsx`, where selecting a result links to a real `apps/web/app/forecast/[locationId]/page.tsx` lookup. Device geolocation now done too: apps/api's `POST /v1/locations/resolve` already accepted a raw `lat`/`lng` point, so this was entirely `apps/web` — a new `app/api/locations/resolve/route.ts` BFF proxy and `app/components/use-my-location-button.tsx`, navigating straight to the resolved forecast (a device reading has exactly one answer, nothing to confirm, unlike a text-search result). Caught and fixed a real self-inflicted bug along the way: sprint 44's `Permissions-Policy` header shipped `geolocation=()` (fully closed, correctly anticipated at the time as this sprint's job to loosen) and a real browser genuinely enforced it, silently blocking `navigator.geolocation` — fixed by scoping it to `geolocation=(self)`. Verified with real Playwright-injected device coordinates: a granted-permission click resolves and calls the real endpoint, correctly hitting this sandbox's blocked-network `gate_coastal_point` 422 (same class of limitation as this session's other live-upstream-dependent features) with a clear message; a denied-permission click shows the right message; the actual success path (resolve → navigate) verified via a mocked BFF response, this repo's established live-network-blocked-path technique via request interception rather than a throwaway page. `axe-core` 0 violations across desktop/mobile × light/dark. Map search and station-preview/ambiguity states remain not attempted — map search needs a real map-tile/geocoding provider and credentials this session doesn't have, flagged the same way sprints 9/10's hosting credentials are; empty-results and fetch-failure states are handled distinctly, and an unknown location 404s via Next's `notFound()` |
| 32 | Dashboard hierarchy | Go/no-go as a simple traffic-light headline (score/narrative expandable, not primary); best window, conditions, confidence, freshness first | **Complete** — hierarchy restructuring on the single-location forecast page: `apps/web/app/components/forecast-card.tsx`'s `ForecastCard` leads with an enlarged verdict `Badge` (the traffic light), a `deriveBestWindow`-derived "best window" callout (computed purely from `hourly_outlook`, no new fetch), a new `ConditionsSummary` (wind/wave/water-temperature, one line, e.g. "Wind 10–15 kt SW · Waves 2–3 ft · Water 76°F"), then confidence/state/freshness, then the numeric score/narrative demoted into a `<details>`/`<summary>`. `ConditionsSummary` reads `apps/api/app/domain/assembly.py`'s `ForecastConditions.wind_range_kt`/`wave_range_ft`/`wind_direction` fields — the exact already-reconciled range `score_conditions` was computed from — rather than re-deriving that reconciliation policy on the frontend. The multi-location dashboard itself, blocked on sprint 37's saved locations, closes out now that they exist: `apps/web/app/saved/page.tsx` fetches every saved location's own forecast server-side in parallel and `app/saved/saved-locations-list.tsx` renders each with the exact same `VERDICT_TO_BADGE`/`deriveBestWindow` mapping the full forecast page uses (both exported from `forecast-card.tsx` for this, alongside a new shared `formatBestWindowRange`) rather than a second mapping invented for the list — a location whose own forecast fetch fails still renders its name/link, not a broken page. Verified against real running `next start`/`uvicorn`/local-Postgres servers: registered, saved a real spot, confirmed `/saved` renders its actual verdict badge and a real best-window callout (`hourly_outlook` never degrades to `null` even on this sandbox's blocked-upstream path, per sprint 34) rather than a mock preview. A fresh `axe-core` sweep (light/dark, 360px phone width) found 0 violations, no overflow. `npm run lint`/`build` clean |
| 33 | Conditions experience | Full/partial/stale/unavailable source-attributed snapshots | **Complete** — `apps/web/app/components/forecast-card.tsx`'s `ForecastCard` renders `forecast.state` as a badge using apps/api's own fresh/stale/partial/unavailable vocabulary, and `SourceStatusList` shows every fanned-out source individually (human-readable label, ok/degraded/unavailable badge, raw provider error for non-ok sources) — real per-source attribution, not just the aggregate already shown. Originally verified against this sandbox's real running server (network-egress-blocked, so the live path only ever produces `partial`/`unavailable`) plus a fresh `axe-core` re-audit that caught and fixed a real text-overflow bug (long provider-error URLs not wrapping at phone width). The `fresh` and `stale` states, and a multi-source `degraded` fan-out, had never actually been rendered or axe-checked — closed with a temporary mock preview page (same throwaway technique as sprints 32/34) covering all four states plus warnings, screenshotted in light/dark and axe-checked (zero violations), then deleted before commit, `npm run build`'s route table confirmed unaffected |
| 34 | Tides and timing | Accessible charts, text alternatives, timezone/DST tests | **Complete** — backend, tides: `apps/api/app/domain/assembly.py` fetches tide predictions (`app.providers.noaa_coops.fetch_tide_predictions`) in the same `asyncio.gather` as the other independent sources, for a local-date window computed in the location's own timezone (`app.infra.timezones.safe_zone`, not naive UTC, DST-safe per sprint 14's `zoneinfo`-based parsing tests); `ForecastTides` is the sprint-34-owned shape of `ForecastEnvelope.tides`, degrading to `None` with an advisory `Warning` on failure. Backend, timing: `apps/api/app/domain/timing.py`'s `build_hourly_outlook` ports the legacy 24-hour fish-activity timeline from typed inputs already on hand, populated on every request (never degrades to `None`, unlike `tides`) — pressure-trend and the profile-dependent parts of the legacy "best times" summary are deliberately deferred, see the module docstring. Frontend, text alternatives: `apps/web/app/components/forecast-card.tsx`'s `TideTable`/`HourlyOutlookTable` are plain, properly-labeled `<table>`s (times in the *location's* timezone, not the viewer's). Frontend, accessible charts: `TideChart` (a point chart with straight lines between real predictions, not an interpolated curve — inventing an in-between shape would misrepresent NOAA's own `hilo`-only predictions product) and `HourlyOutlookChart` (a bar chart) — both single-hue sequential encodings on `--color-primary` per the `dataviz` skill's form heuristic for a magnitude series, both `aria-hidden="true"` alongside their already-complete text tables. `HourlyOutlookTable`/`HourlyOutlookChart` were verified against the real, live forecast page (`hourly_outlook` never degrades to `None`); `TideTable`/`TideChart` were verified against a temporary mock preview page (`tides` is always `None` on this sandbox's live path) — all four with a fresh `axe-core` spot-check, zero violations, no overflow. Sprint 32's "best window" headline built from this data is done (see that row) |
| 35 | Fishing guidance | Limited supported suggestions; every recommendation explains why | Existing broad feature is out of scope; adapt |
| 36 | Preferences | Units, thresholds, style, default location persistence | **Complete** — `GET`/`PATCH /v1/me/preferences`, the last of the canonical roadmap's six required `/v1` endpoints, closes out. `apps/api`: `app/infra/database.py` (async SQLAlchemy engine scoped to ADR-006's `forecast` schema via `search_path`, a least-privilege `saltline_api` role owning it alone — no grant on `public` or `apps/web`'s own `auth` schema), `app/domain/preferences.py` (the `UserPreferences` model, keyed by Better Auth's opaque user id — never an email/password/session token, per ADR-006's data split; field set deliberately narrower than `v2/backend/app/models/profile.py`'s broader personalization, matching `docs/product-definition.md`'s "V1 capabilities" list exactly rather than adding scope indirectly), `app/api/v1/preferences.py` (the one router that actually requires a real signed-in user — every other route's signature check just proves the caller is `apps/web`'s BFF; this one 401s on an empty `user_id`, the field ADR-004 always signed but nothing needed until now). Migrations via Alembic. 11 new tests against an ephemeral SQLite in-memory database (no live-Postgres CI dependence), plus a real local-Postgres verification (a real signed `PATCH`, confirmed the row landed in `forecast.user_preferences`). `apps/web`: `lib/internal-api-client.ts` gains the `userId` parameter its own docstring already anticipated back when sprint 28 was blocked; `app/api/preferences/route.ts` (BFF proxy, 401s via Better Auth's `getSession()` before ever reaching apps/api); `/preferences` (`app/preferences/page.tsx`) — the first page in this app requiring a session, checked server-side, `redirect('/login')` before any client code runs; deliberately *not* sprint 29's broader account-required-routing policy, just this one page's own need. `PreferencesForm` built the one new UI pattern the design system didn't have yet (a units toggle, no `<select>` primitive exists) by hand as a `role="radiogroup"`; everything else needed zero new primitives. Verified end-to-end against real running `next start`/`uvicorn`/local-Postgres servers: anonymous redirect, register → fill every field → save → reload → every value persisted exactly, an invalid `default_location_id` rejected with a visible error. `axe-core` 0 violations both themes. Full check suites (`ruff`/`ruff format`/`mypy`/`pytest` — 359 passed; `npm run lint`/`build`) clean |
| 37 | Saved locations | Ordered favorites, ownership, duplicates, deletion, empty state; ownership model built so a free-tier cap (target: 1 location) is a natural later addition, without building billing now | **Complete** — `apps/api`: a new `saved_location` table (Alembic migration) in the same `forecast` schema `user_preferences` uses, no `ForeignKey` to it (a preferences row isn't guaranteed to exist first). `GET`/`POST /v1/me/locations` and `DELETE /v1/me/locations/{id}`, behind the same `require_authenticated_user_id` dependency preferences already used (now shared via `app/api/deps.py`). `POST` validates the `location_id` through `resolve_location_id` (422 on unresolvable) and 409s on a duplicate `(user_id, location_id)` save (a real `UniqueConstraint`); `DELETE` 404s for both a missing row and one owned by another user, so a request can't fingerprint another user's saved-location ids. `MAX_FREE_TIER_LOCATIONS = 1` is a named constant per this row's own "ownership model built so a free-tier cap is a natural later addition" bar — recorded, not enforced by any route yet, since enforcing it is a real product/billing decision this sprint's acceptance bar deliberately doesn't ask for. 12 new tests (ownership isolation, duplicates, ordering, both 404 cases, 401 on every method with no session). `apps/web`: BFF proxy routes sharing a new `requireSessionUserId()` helper with preferences' own route; `SaveLocationButton` on the forecast page (a click always ends in "Saved" whether it was a fresh `201` or an already-saved `409` — the same outcome from the visitor's side); `/saved`, a session-gated ordered list with a remove action and an empty state. Caught and fixed a real bug in `lib/internal-api-client.ts` along the way (it unconditionally parsed `response.json()`, which throws on the new `DELETE` route's `204 No Content`). Replaced `AuthStatus`'s old flat "name link + sign out button" with a `role="menu"` account dropdown (Preferences/Saved spots/Sign out) now that there are two destinations to fit — end-to-end verification at a real 360px phone width caught that its first pass (an icon+name trigger capped at `max-w-[9rem]`) still regressed the exact mobile crowding sprint 28 fixed once already, since a truncated-but-still-wide box can overflow a row regardless of what's inside it; fixed the same way sprint 28 did, name hidden below `sm`, icon-only (labeled via `aria-label`) at phone width. Verified end-to-end against real running `next start`/`uvicorn`/local-Postgres servers: register → save a spot → view/remove it on `/saved` → duplicate-save still reads as "Saved" → account menu's Saved spots link, all confirmed with a real browser, plus the mobile-width fix re-verified with an intentionally long display name. `axe-core` 0 violations (forecast page light/dark, `/saved`). Full check suites clean on both apps (`ruff`/`ruff format`/`mypy`/`pytest` — 371 passed; `npm run lint`/`build`). The multi-location *dashboard* (listing every saved location's own forecast, not just this sprint's list-of-links) was sprint 32's own remainder, not this sprint's job — see that row's updated entry for its own follow-up close-out |
| 38 | PWA baseline | Installable shell with full offline navigation and graceful degradation, not just last-cached-forecast viewing; authenticated forecasts not cached forever | Candidate in `/v2` |
| 39 | Responsive polish | Layout shift, assets, tap targets, Lighthouse, screenshot budgets | **Complete** — Lighthouse/assets (a real Lighthouse audit, mobile, all four categories, against a real production build for `/`, `/locations`, and `/forecast/wrightsville-beach-nc` — accessibility/best-practices/SEO all 100, performance 96-98; found and fixed a real missing-favicon bug, `best-practices` 96→100; noisy sandbox performance-timing audits recorded as baseline, not chased) was already done. The three remaining items: **layout shift** — real Cumulative Layout Shift measured via the browser's own Layout Instability API (`PerformanceObserver`, the same signal Lighthouse itself reads) across every page x 2 viewports, both on initial load and through `LocationSearch`'s open/select interaction — 0.0000 everywhere, since the dropdown's `position: absolute` popup never reflows surrounding content. **Tap targets** — axe-core's `target-size` rule is tagged `wcag22aa` but ships *disabled by default*, so sprint 40's tag-based sweep silently skipped it; ran it explicitly enabled across every page x 2 viewports — 0 violations — cross-checked independently with a manual Playwright `boundingBox()` measurement of every real interactive element (including the search dropdown's open options) against the WCAG 2.5.8 24x24 CSS px minimum — 0 undersized. **Screenshot budgets** — this ledger phrase has no prior definition anywhere in the repo; interpreted conservatively as a literal full-page-PNG byte-size ceiling (1.5MB) per page x viewport, explicitly *not* a full visual-regression CI system (tool choice and baseline storage/review workflow is a separate process decision, not made here) — all pages measured well within budget (29KB-274KB) |
| 40 | Accessibility pass | WCAG 2.2 AA, axe plus keyboard/screen-reader evidence | **Complete** — a real `axe-core` sweep (`wcag2a`/`wcag2aa`/`wcag22aa`) across every page x 2 viewports x 2 color schemes, plus `LocationSearch`'s interactive dropdown states specifically (the earlier per-sprint spot-checks only ever covered pages at rest) — 0 violations. A scripted keyboard-only walkthrough (Tab to the combobox, type, Arrow through results, Escape, re-open, Enter to select, Tab away) confirmed focus order, visible focus rings, and no keyboard trap. Playwright's `page.accessibility.snapshot()` gives automated accessibility-tree evidence (real names/roles/disabled-state reaching the platform tree) — explicitly not a claim of testing with real screen-reader software, which this environment can't run. Found and fixed three real bugs in the process: (1) `LocationSearch`'s combobox `aria-controls` pointed at a listbox `<div>` that only existed when there were results, dangling in the zero-match state (`aria-valid-attr-value`) — fixed by always rendering the listbox and toggling it with the native `hidden` attribute (the ARIA APG combobox convention), with the "no matches" state rendered as a disabled `role="option"` row rather than a sibling `<p>` so an always-present `role="listbox"` never has zero owned children; (2) `ForecastErrorCard`'s troubleshooting text named `INTERNAL_SIGNING_KEY_SECRET` in an unbreakable inline `<code>`, overflowing past a 390px mobile viewport (WCAG 1.4.10 Reflow — axe-core can't catch this automatically, only the sweep's own overflow check did), fixed with the same `break-words` class already used one line above it; (3) the keyboard walkthrough caught selecting a result re-triggering the debounced search effect on the newly-filled query and reopening the dropdown ~300ms later with no user action, fixed with a ref flag that skips exactly one search-effect run after a selection. See `apps/web/README.md`'s sprint-40 paragraph for the full account |

### Phase 4 — Make it operable and launch it

| Sprint | Outcome | Acceptance focus | Current state |
|---:|---|---|---|
| 41 | Structured observability | One request trace across web/API/sources with safe context | **Partially complete** — the dependency-free half, no observability vendor: `apps/api/app/infra/request_logging.py`'s `log_requests` middleware emits one structured JSON trace line per request (`request_id`/method/path/status_code/duration_ms, "safe context" — no query string, headers, or body), correlated with `apps/web/lib/internal-api-client.ts`'s own trace line for the same call via ADR-004's `X-Internal-Request-Id` header (already generated for signing, not a new correlation scheme). Fires even for requests that never reach a route handler (an unsigned/unauthenticated call), since it wraps the whole ASGI call. Caught and fixed a real bug in the process: the middleware's `logger.info(...)` calls were silently dropped under a real `uvicorn app.main:app` run (no handler attached — uvicorn only wires up its own loggers, and pytest's `caplog` fixture had been masking this by attaching its own handler regardless) — fixed by giving the logger its own `StreamHandler`. Verified end-to-end against two real running servers: grepped the same `request_id` out of both services' real log output for one real page load, not asserted from unit tests alone — and in the process caught and corrected a real inaccuracy in sprint 49's fetch-deduplication claim (see that row). Per-source (NWS/NOAA CO-OPS/NDBC provider) log lines remain uncorrelated with the request trace — a larger refactor threading the request id through every provider call, not attempted here without evidence it's worth the churn |
| 42 | Error monitoring | Frontend/API releases, source maps and secret redaction | Not accepted |
| 43 | Privacy-safe analytics | Registration, resolution, forecast state, latency, return use | Not accepted |
| 44 | Security hardening | CSP, CSRF, signed internal API, brute force, headers, threat model | **Complete** — the signed-internal-API piece was built **and wired end-to-end**: `apps/api/app/infra/internal_signature.py` + `app/api/internal_auth.py` implement ADR-004's HMAC-SHA-256 contract (no legacy precedent), required on every `/v1` route via `Depends(require_internal_signature)`; `apps/web/lib/internal-signature.ts` + `internal-api-client.ts` are the matching signer, exercised by `apps/web/app/forecast/demo/page.tsx`. CSP and security headers were also done: `apps/web/next.config.ts`'s `headers()` attaches a self-only `Content-Security-Policy` plus `X-Content-Type-Options`/`X-Frame-Options`/`Referrer-Policy`/`Permissions-Policy`/`X-Permitted-Cross-Domain-Policies`/`Strict-Transport-Security` to every response, adapted (stricter, since apps/web has no third-party origins yet) from the legacy Flask app's `_set_security_headers`; verified against a real production build/server, not just `next dev` — real headers on static/dynamic/Route-Handler responses, a full headless-Chromium interactive pass confirming zero actual CSP violations, and a fresh `axe-core` spot-check. CSRF and brute-force defense, this row's own note said, needed Better Auth (sprint 28) and real mutating authenticated endpoints (sprints 36/37) to be meaningful — both now exist, so this closes out: brute-force defense is Better Auth's own per-action rate limiting (verified live in sprint 28 — 7 rapid sign-in attempts, exactly 5 allowed before a real `429`). CSRF gets two independent layers on every BFF route with real per-user data (`lib/require-session-user-id.ts`, shared by `app/api/preferences/route.ts` and `app/api/saved-locations/route.ts`): the session cookie's own `SameSite=Lax` policy, and a new explicit `Origin` header check (`403` on mismatch) added as defense-in-depth per ADR-005's literal "state-changing web routes enforce origin and CSRF validation." Verified live, not just configured: a real cross-site `<form>` POST (the actual CSRF vector, not a CORS-only claim) got no session cookie at all and was rejected; a second test manually attached a valid session cookie with a forged `Origin` header and got an explicit `403 origin mismatch`, proving the new check is a real second layer, not redundant with the cookie policy alone; a legitimate same-origin request still succeeds normally. `docs/THREAT_MODEL.md` is the last named piece — a boundary-by-boundary (browser↔BFF, BFF↔FastAPI, FastAPI↔providers, database) threat/mitigation/evidence table citing the real file or test behind each mitigation, plus an explicit accepted-residual-risk section (CAPTCHA gap, no WAF/DDoS layer, no continuous dependency scanning, live-upstream threats untestable in this sandboxed environment) rather than only listing what's covered |
| 45 | Privacy and deletion | **Required for v1 launch** (public product, real accounts): self-service export and account deletion/anonymization proof; legal pages | **Partially complete** — self-service export and account deletion, the round-2 product decision's explicit v1-required carve-out, are both done. `apps/api`: a new `app/api/v1/account.py` router, `GET /v1/me/export` (the literal stored rows for the caller — preferences fields, saved locations' `location_id`/`saved_at` — not re-derived data; a saved location's name/state is public curated data, not personal data this account holds) and `DELETE /v1/me` (clears both tables this service owns for that user, `user_preferences` and `saved_location`). `apps/web`: `lib/auth.ts` enables Better Auth's built-in `user.deleteUser` (off by default), confirmed via the current password rather than an email-verification-token flow that would add a second, SMTP-dependent path for no real gain; its `beforeDelete` hook calls apps/api's `DELETE /v1/me` before Better Auth removes the `auth`-schema account row, so no `forecast`-schema data outlives a deleted account — the two schemas ADR-006 splits between apps have no shared foreign key to cascade this automatically. New `/account` page (session-gated like `/preferences`, linked from the account menu): a plain download link to a new BFF export route (merging Better Auth's own account fields with apps/api's export, `Content-Disposition: attachment`) and a two-step delete-confirmation form (password, then an explicit second button) rather than a one-click path for an irreversible action. Verified end-to-end against real running `next start`/`uvicorn`/local-Postgres servers, not just wired: registered, set real preferences, saved a real location, downloaded and confirmed the real merged export content, confirmed a wrong password is rejected, then deleted the account for real with the correct password — confirmed via direct SQL against *both* Postgres schemas that every row was actually gone afterward (not just that a subsequent login failed), and confirmed re-login with the same credentials is rejected. A fresh `axe-core` sweep (desktop/mobile × light/dark, delete-confirmation form open) found 0 violations and no overflow; the account menu's now-four items still fit at 360px. Full check suites clean on both apps (`ruff`/`ruff format`/`mypy`/`pytest` — 380 passed; `npm run lint`/`build`). **Legal pages** (real Terms of Service/Privacy Policy copy) remain open — needs real legal review this session can't supply, flagged the same way sprint 28's CAPTCHA credentials gap is, not guessed at |
| 46 | Database resilience | Migrations, constraints, indexes, pooling, backups, blank restore drill | Not accepted |
| 47 | Degraded-mode UX | Database/API/email/upstream chaos yields actionable UI | Not accepted |
| 48 | Release controls | Promotion, migration gate, smoke, rollback and staging drill | Not accepted |
| 49 | SEO and sharing | **Required for v1**, not just later phase-4 sequencing: public non-personal forecast pages (organic-growth surface); private dashboards | **Complete** — the "public non-personal forecast pages" half originally shipped at `apps/web/app/forecast/[locationId]/page.tsx`'s own URLs; sprint 29 ("account-required routing") gated that route behind a session, so this sprint's public surface **moved to `app/share/[locationId]/page.tsx`** instead of being lost — same real per-location `generateMetadata` (title, description, canonical URL, OpenGraph tags — static copy, never live score/warning text), same `internalApiFetch` call (now shared via `lib/get-forecast.ts` rather than copied), same visual layout (shared via `app/components/forecast-page-body.tsx`/`forecast-loading-body.tsx`, since the authenticated and public pages differ only in their back-link and an added sign-up call to action on the public one). `app/page.tsx`'s "Popular spots" links point at `/share/*` now, not the since-gated `/forecast/*`. `app/layout.tsx` gains `metadataBase`/a title template/OpenGraph+Twitter defaults; `app/opengraph-image.tsx` generates a real 1200×630 PNG link-preview card via `next/og` (design-system palette, no new branding decision). The "private dashboards" half is real: `app/robots.ts` disallows `/locations`, `/forecast/`, `/preferences`, `/saved` (sprint 37's session-gated dashboard, a real gap found and fixed closing this row out — it postdated this list's last review), and `/api/`, while keeping `/` and `/share/*` allowed. This row's one remaining named piece, a real `sitemap.xml`, closes out now too: `apps/api`'s new `GET /v1/locations` (an unfiltered enumeration `/v1/locations/search`'s query-based shape couldn't give) backs `apps/web/app/sitemap.ts`, one URL per curated location's `/share/*` page plus the home page, referenced from `robots.ts`'s `sitemap` field. Verified against real running servers — `curl` for the metadata/robots/sitemap shape (`/sitemap.xml` returns exactly 102 entries, matching the curated dataset's real 101-location size plus the home page; two sampled `/share/*` URLs from it both resolve `200`), a real browser for the share page's rendered content and its sign-up CTA — plus a fresh `axe-core` spot-check, zero violations. Full check suites clean on both apps (`ruff`/`ruff format`/`mypy`/`pytest` — 373 passed; `npm run lint`/`build`) |
| 50 | Launch readiness | Cross-device, load, security, a11y, restore, outage evidence | Not accepted |
| 51 | Limited beta | Small angler cohort recruited via personal network and local fishing communities (not a public open beta); severity/reproduction report | Not accepted |
| 52 | Public-launch runbook | Owners, freeze rules, alerts, go/no-go and rollback triggers | Not accepted |
| 53 | Production promotion | Validated release promoted through the release controls | Not accepted |
| 54 | Production smoke suite | Account, location, forecast and degraded-path smoke evidence | Not accepted |
| 55 | First-hour observation | Live error, latency, source and database health review | Not accepted |
| 56 | First-24-hour review | Health report and only launch-blocking remediation | Not accepted |
| 57 | Reliability baseline | Actual p50/p95, upstream failure and forecast completion recorded | Not accepted |
| 58 | Signup-funnel baseline | Registration and onboarding completion recorded; directional 6-12 month target is low thousands of active users | Not accepted |
| 59 | Return-usage baseline | Privacy-safe early return-use evidence recorded | Not accepted |
| 60 | Highest-impact reliability fix | One measured gap fixed with before/after evidence | Not accepted |
| 61 | Expansion option studies | Recommendations, alerts, catches, regulations, native apps compared; leading candidates per owner intent are a ~$1/month subscription tier and paid growth acquisition | Not accepted |
| 62 | Expansion decision record | Usage, value, risk, cost and architecture decision proposed | Not accepted |
| 63 | Expansion commitment | User-approved next investment recorded as a new roadmap | Not accepted |

Sprints 52-63 deliberately decompose the former broad public-launch,
post-launch-review, and expansion-decision work into mergeable, auditable
steps. They do not authorize any expansion feature by themselves.

## Definition of ready for every sprint

Before implementation begins, the issue must state:

- one outcome and explicit non-goals;
- dependencies and confirmation that their PRs are merged;
- exact acceptance criteria and test commands;
- API/schema/migration impact;
- security, privacy, accessibility, failure-mode, and observability impact;
- expected UI evidence where relevant.

## Definition of done and AI verification contract

Every sprint is exactly one small PR. Each PR includes:

- captured automated check results;
- mobile screenshots or recordings for visible changes;
- OpenAPI diff for interface changes;
- forward and rollback notes for database changes;
- an AI review for correctness, edge cases, scope growth, weak tests,
  secrets, and backward incompatibility;
- a second AI pass after fixes;
- resolution or evidence-backed rejection of every blocking finding;
- roughly no more than 400 changed implementation lines, excluding generated
  code, fixtures, and documented mechanical moves.

Do not begin a dependent sprint until the current PR is merged. A commit on a
local branch, a pushed branch, or an open PR is not done.

## Cross-agent handoff protocol

Before switching from Codex to Claude, Claude to Codex, or to a human:

1. Merge or explicitly abandon the current PR. Never leave its status implied.
2. Update the checkpoint below in the same PR when possible.
3. Update issue #318 with the last merged PR and check results.
4. Record blockers and decisions with evidence, not chat references.
5. Name one exact next action and its non-goals.

### Restart instructions for the next agent

1. Fetch and switch to the latest `main`.
2. Read `AGENTS.md`, this document, and issue #318.
3. Confirm that the checkpoint's last merged PR is actually in `main`.
4. Inspect related code and tests before proposing a change.
5. Create a branch for only the named gate/sprint.
6. Stop if a new product decision is required; record and ask rather than
   silently choosing a different architecture.

## Live checkpoint

**Session note (unmerged, this branch):** five more rows advance —
sprint 32 (the multi-location dashboard), sprint 49 (a real
`sitemap.xml`), sprint 44 (CSRF, brute-force, threat model), sprint 31
(device geolocation), and sprint 45 (self-service export/deletion) —
see those rows in the sprint ledger above for the full account, and
`apps/api`/`apps/web`'s READMEs' Status sections. Short version: sprint
32's own docstring had named its dashboard piece as blocked on sprint
37's saved locations, merged in PR #385 just before this branch
restarted from `main`; with a real `/v1/me/locations` to list,
`app/saved/page.tsx` now fetches every saved location's own forecast
server-side and renders it with the same verdict-badge/best-window
mapping the single-location forecast page already uses (both exported
from `forecast-card.tsx` for this reuse). Sprint 49's `app/robots.ts`
had been carrying a docstring since that sprint first shipped
explaining why it emitted no `sitemap` directive — no endpoint could
enumerate every curated location; a new `GET /v1/locations` (apps/api)
closes that gap, backing `apps/web/app/sitemap.ts`. Fixing that also
surfaced a real, unrelated gap in the same file: `/saved` (sprint 37,
added after `robots.ts`'s `Disallow` list was last reviewed) was
missing from it — added. Sprint 44's own note said CSRF/brute-force
needed sprint 28's Better Auth and sprints 36/37's real mutating
endpoints to be meaningful — both exist now: brute-force defense
(Better Auth's per-action rate limiting) was already real from sprint
28; CSRF gets a new explicit `Origin` check in `lib/require-session-
user-id.ts` as a second layer alongside the session cookie's existing
`SameSite=Lax` policy, verified live with a real cross-site `<form>`
POST (rejected, no session cookie attached) and a separate forged-
`Origin`-with-a-valid-cookie request (rejected with an explicit `403`,
proving the new check is a real second layer). `docs/THREAT_MODEL.md`
(new) is sprint 44's last named piece — a boundary-by-boundary threat/
mitigation/evidence table plus an explicit accepted-residual-risk
section. Sprint 31's device geolocation needed no apps/api work
(`POST /v1/locations/resolve` already took a raw point) — a new BFF
proxy and `UseMyLocationButton`, navigating straight to the resolved
forecast. Caught a real self-inflicted bug doing it: sprint 44's own
`Permissions-Policy` header shipped `geolocation=()` (correctly
anticipated as this sprint's job to loosen, but still a real live-
browser block, not just a stale comment) — fixed to `geolocation=
(self)`. This sandbox's blocked network means `gate_coastal_point`
422s on every real point (verified that failure path renders a clear
message); the actual success path was verified via a mocked BFF
response instead, this repo's established live-network-blocked-path
technique via request interception. Verified against real running
`next start`/`uvicorn`/local-Postgres servers throughout: the
dashboard's real (non-mocked) best-window callout; `/sitemap.xml`
returning exactly 102 entries (101 curated locations + the home page)
with two sampled `/share/*` URLs from it both resolving `200`; the
CSRF tests above; and the geolocation tests (granted/denied
permission, and the mocked success path). Sprint 45's self-service
export/deletion closes out the one carve-out the round-2 product
decision pulled forward as v1-required (not deferred with the rest of
that sprint's row): apps/api's new `GET /v1/me/export`/`DELETE /v1/me`,
and apps/web's new `/account` page wiring Better Auth's built-in
`deleteUser` (a `beforeDelete` hook cleans up apps/api's
`forecast`-schema data first, so no per-user data outlives a deleted
account across the two schemas ADR-006 splits). Verified for real, not
just wired: registered, set real data, downloaded and checked the
actual export content, confirmed a wrong password is rejected, then
deleted the account with the correct password and confirmed via direct
SQL against both Postgres schemas that every row was actually gone —
not just that a subsequent login failed. "Legal pages," that row's
other named piece, needs real legal review this session can't supply,
flagged rather than guessed at. The rest of
this checkpoint section (below) predates this work — its "Last merged
PR" pointer is stale pending this branch's own merge; treat the sprint
ledger table above as the authoritative current state, not this
narrative.

- Last merged PR: #385 (sprints 28 (Authentication, partially
  complete), 36 (Preferences, complete), 29 (Account-required routing,
  complete), and 37 (Saved locations, complete) — see those rows in the
  sprint ledger above for the full account of each. Short version: the
  standing "Better Auth + Postgres infrastructure decisions that don't
  exist yet" blocker turned out narrower than recorded here — a real
  local Postgres was available, so email/password auth (Better Auth, a
  real `auth` schema, rate limiting, verification/reset email, four new
  pages) shipped against it, and once it existed, sprint 36's
  `GET`/`PATCH /v1/me/preferences` (the last required `/v1` endpoint,
  apps/api's own first Postgres connection, a separate `forecast`
  schema and role per ADR-006) followed naturally. With a real account
  system in place, sprint 29 gated `/locations` and
  `/forecast/[locationId]` behind a session per
  `docs/product-definition.md`'s "core browsing requires a verified
  account" — a product-owner call made explicit that session
  (search/forecast require login now, not just save/preferences),
  which meant relocating sprint 49's already-shipped public share page
  off those same URLs to `/share/[locationId]` rather than losing it.
  Sprint 37 then followed the same `forecast`-schema/ownership pattern
  sprint 36 established for a second table (`saved_location`, no FK to
  `user_preferences` since one isn't guaranteed to exist first), added
  the "save/list/delete" `/v1/me/locations` routes and their
  `apps/web` UI, and replaced `AuthStatus`'s old two-item layout with a
  real account-menu dropdown now that Preferences and Saved spots both
  need a home — catching and fixing a real mobile-width regression of
  sprint 28's own header-crowding fix along the way. Sprint 28's only
  open piece is bot/CAPTCHA defense (needs real third-party
  credentials); sprints 9/10's Vercel/Render/Neon gap is still the
  standing blocker for anything needing the real production database
  or hosting, not local development).
- Previously last merged PR: #382 (finishes sprint 27's Saltline rebrand: the
  forecast and search pages' actual layout reworked to match the
  reviewed concept — a real photo-hero band, a coral-tinted best-window
  callout, a sunken conditions panel, and a restyled search dropdown —
  not just the token-level recolor #380 shipped. Caught a second real
  contrast bug the same way as the first, before it hit CI — `5b4a5f4`,
  merged as `30b2832`). See the checkpoint narrative below and
  `apps/web/README.md`'s "Follow-up layout pass" paragraph for the full
  account. The Saltline rebrand (branding + layout) is now complete
  end-to-end.
  **Process note (#380, still relevant)**: that PR was opened and
  merged automatically within 7 seconds of the push, before its own CI
  run finished — every other PR this session went through an explicit
  `create_pull_request` call and waited for a green check run first;
  this one didn't, the human merged it directly, quickly. The change
  was still fully verified locally beforehand, and all 22 check runs
  finished green shortly after, confirmed via the Actions API — `main`
  was never red. #381 and #382 both went through the normal wait-for-
  green flow, so this looks like a one-off rather than a standing
  automation; worth the next agent's awareness regardless in case it
  recurs on a change that doesn't pass.
- **All recovery gates (R0-R3) are complete.** Phase 1 sprints complete:
  1-3 (#333), 4 (#326), 5 (#327), 6 (#329 + #330 revert), 7 (#331), 8
  (#332). Phase 1's only remaining items (9, 10) need external accounts —
  see below.
- **Phase 2** started with **sprint 11** (canonical domain
  model, #334): `apps/api/app/domain/models.py` — fresh Pydantic models
  (`Location`, `Observation`, `SourceStatus`, `Confidence`, `Warning`,
  `ForecastEnvelope`) per `docs/architecture.md`'s ADR-003, not ported
  from `v2/backend/app/schemas/` (those are auth-coupled DTOs per
  `docs/R1_RECONCILIATION_AUDIT.md`). `ForecastEnvelope.conditions`/
  `tides`/`hourly_outlook`/`recommendations` are deliberately left as
  opaque `dict[str, Any] | None` — designing those shapes belongs to the
  sprints that own them (21, 22, 34, 35), each behind characterization
  tests, not invented here without evidence. `apps/api/tests/
  test_domain_models.py` covers serialization round trips and JSON
  schema-snapshot drift detection (snapshots committed under
  `apps/api/tests/schema_snapshots/`); drift detection verified locally
  by deliberately adding a field, confirming the test failed, then
  reverting — not just assumed to work. `apps/api/scripts/
  generate_schema_snapshots.py` regenerates snapshots after a deliberate
  model change.
- This PR continues Phase 2 with **sprint 12** (HTTP client policy):
  `apps/api/app/infra/http_client.py` — `BoundedHTTPClient`, an async
  context manager over `httpx.AsyncClient` per `docs/architecture.md`'s
  ADR-003 ("bounded concurrency, explicit timeouts, limited retries, and
  response-size limits"). Explicit connect/read/write/pool timeouts;
  bounded exponential-backoff retries limited to transient failures
  (connection errors, timeouts, 429/502/503/504 — never 4xx, which won't
  succeed on retry); a response-size limit enforced by streaming and
  counting bytes rather than trusting `Content-Length`; a fixed
  identifying `User-Agent`; structured `ProviderError` subclasses
  (`ProviderConnectionError`, `ProviderTimeoutError`,
  `ProviderHTTPStatusError`, `ProviderResponseTooLargeError`) instead of
  leaking raw `httpx` exceptions. Has no knowledge of any specific
  provider's payload shape — every future provider adapter (NWS, NOAA
  CO-OPS, NDBC — sprints 13-16) is built on this. `apps/api/tests/
  test_http_client.py` covers success, retry-then-succeed on 503 and on
  timeout, retry exhaustion raising `ProviderHTTPStatusError`, no retry
  on 404, `ProviderTimeoutError`, `ProviderConnectionError`, and
  oversized-response rejection — all via `httpx.MockTransport`, no live
  network calls, per the R2 no-live-provider-dependence rule.
  `apps/api/pytest.ini` gained `asyncio_mode = auto` for the new
  `pytest-asyncio`-based async tests. All of `apps/api`'s checks (ruff,
  ruff format, mypy, pytest — 24 passed) pass clean.
- This PR continues Phase 2 with **sprint 13** (NWS provider adapter,
  partial — see the sprint-ledger row for the exact deferral):
  `apps/api/app/providers/nws.py` — marine-zone wind/wave/direction
  parsing (`parse_marine_zone_conditions`) and fetch
  (`fetch_marine_zone_conditions`, propagates `ProviderError` since
  marine conditions are decision-relevant), plus point and state
  active-alerts parsing (`_parse_alerts`, unifying the legacy module's
  two near-duplicate GeoJSON/JSON-LD parsers) and fetch
  (`fetch_point_alerts`/`fetch_state_alerts`, catch `ProviderError` and
  return `[]` since alerts are non-critical enrichment — matching the
  legacy resilience posture). Ported from `services/nws.py` behind
  `apps/api/tests/test_nws_provider.py`'s fixture-based characterization
  tests (abbreviated/spelled-out wind direction, "around Nft" phrasing,
  min/max across the first 3 periods, missing fields, both alert JSON
  shapes, truncation/limit behavior, and fetch-layer error handling via
  `httpx.MockTransport`) rather than a verbatim carry-over. Gridpoint
  wind fallback and current-weather observations (heat index, recent
  precipitation) are deliberately deferred — see the module docstring —
  to keep this PR reviewable; tracked as follow-up before sprint 21
  (forecast assembly) needs them. All of `apps/api`'s checks (ruff, ruff
  format, mypy, pytest — 38 passed) pass clean.
- This PR continues Phase 2 with **sprint 14** (NOAA CO-OPS adapter,
  partial — see the sprint-ledger row): `apps/api/app/providers/
  noaa_coops.py` — `fetch_water_temperature` and `fetch_tide_predictions`,
  both raising `NoaaDataUnavailableError` (a `ProviderError` subclass) on
  a valid response with no usable reading, since both are decision-relevant
  (unlike sprint 13's non-critical alerts). The legacy module's
  silent-failure/monthly-average-fallback (`get_water_temp`) is
  deliberately not ported — deciding when to fall back, and recording it
  on `Observation.is_fallback`, is forecast-assembly's job (sprint 21),
  not a single provider adapter's. CO-OPS timestamps are in
  station-local `lst_ldt` time; parsing uses `zoneinfo.ZoneInfo`, which
  (unlike `pytz`) resolves the correct UTC offset via a plain
  `.replace(tzinfo=...)`, verified in `apps/api/
  tests/test_noaa_coops_provider.py` by asserting the correct UTC offset
  on both sides of a DST transition (EDT vs. EST) and that parsing a
  timestamp during the fall-back fold doesn't raise. Also covers missing
  data rows/values (empty `data`/`predictions` lists, missing `v` or
  `t` fields) raising or being skipped rather than silently substituting
  a placeholder, unlike the legacy module's noon-hour fallback quirk.
  Wind/currents/environmental-metrics fetches and the `build_tide_
  chart_svg` rendering helper (not a provider concern) are deliberately
  deferred — see the module docstring. All of `apps/api`'s checks (ruff,
  ruff format, mypy, pytest — 49 passed) pass clean.
- This PR continues Phase 2 with **sprint 15** (NDBC adapter, partial —
  see the sprint-ledger row): `apps/api/app/providers/ndbc.py` —
  `parse_realtime_text`/`fetch_buoy_observation` for NDBC's fixed-width
  `realtime2` text feed (not JSON), so `app/infra/http_client.py`'s
  `BoundedHTTPClient` gained a `get_text` method alongside `get_json`
  (small, tested addition to sprint 12's infra, needed by this sprint).
  Wind speed/gust/direction, wave height, and pressure are each parsed
  independently, taking the first non-missing reading per field across
  the 10 most recent rows — a buoy missing a column (e.g. a wave-only
  buoy has no `WSPD`) leaves that field `None` rather than raising,
  while a provider-specific missing-value marker (`MM`, `99.0`, `999`,
  ...) in a present column is treated the same way; only a station with
  *no* usable reading for *any* tracked field raises
  `NdbcDataUnavailableError`. The legacy module's pressure-trend
  computation and fishing-impact narrative (`fetch_barometric_pressure`)
  are deliberately not ported — those are scoring/narrative concerns
  for sprint 35, not a provider adapter's. Ported from
  `services/ndbc.py` behind `apps/api/tests/test_ndbc_provider.py`'s
  fixture-based characterization tests (full row, all-missing raises,
  partial-missing leaves only those fields `None`, gust-falls-back-to-
  speed, missing column vs. missing value, first-usable-row-per-field,
  short-row skipping, too-few-lines raises). All of `apps/api`'s checks
  (ruff, ruff format, mypy, pytest — 62 passed) pass clean.
- This PR continues Phase 2 with **sprint 16** (astronomy adapter,
  **complete** — the first fully-complete Phase 2 provider sprint, since
  it's pure math with no fetch layer): `apps/api/app/providers/
  astronomy.py` — `compute_sun_times`, `compute_twilight_times`,
  `compute_lunar_details`, `compute_solunar_times`, ported from
  `services/astro.py`'s NOAA simplified solar-position algorithm and
  synodic-month lunar-phase approximation. Returns typed timezone-aware
  `datetime`s instead of the legacy module's pre-formatted 12-hour
  strings, and enums (`MoonPhaseName`, `SolunarRating`) instead of loose
  strings. Two behavior changes beyond typing, both documented in the
  module docstring: the duplicate sunrise/sunset formula
  (`_sun_times` vs. the parameterized `_sun_event_time`) is collapsed
  into one; and the legacy `_sun_times`'s "lat/lng `== 0` means unset,
  substitute a default location" sentinel is dropped as a latent bug
  ((0, 0) is a real point, not a safe "unset" marker) — callers now pass
  real coordinates, no silent fallback. The moonrise/moonset/solunar-
  window day-boundary approximation (an hour-of-day wrapped `mod 24`,
  stamped onto the same calendar date as the input, so a window that
  crosses midnight doesn't roll onto the next day) is carried over
  unchanged, since fixing it needs a materially different algorithm,
  out of scope here. `apps/api/app/infra/timezones.py` (new) extracts
  the `ZoneInfo`-with-fallback helper this adapter needs, shared with
  sprint 14's NOAA CO-OPS adapter (refactored to use it, dropping its
  own copy — two copies was fine, three wasn't). `apps/api/tests/
  test_astronomy_provider.py` covers Atlantic and Pacific coasts,
  summer vs. winter day length, a non-DST-observing timezone
  (`America/Phoenix`), polar-latitude `acos` clamping, and exact
  assertions at the lunar-phase reference instant (new moon → 0%
  illumination, half a synodic month later → full moon) — structural/
  exact assertions rather than pinned against an external ephemeris,
  since the module's formulas are explicitly approximations. All of
  `apps/api`'s checks (ruff, ruff format, mypy, pytest — 75 passed)
  pass clean. This completes the four-sprint provider-adapter run
  (13-16: NWS, NOAA CO-OPS, NDBC, astronomy) the sprint ledger named.
- This PR continues Phase 2 with **sprint 17** (station catalog,
  **complete**): `apps/api/app/providers/stations.py` —
  `fetch_coops_tide_catalog`/`fetch_coops_watertemp_catalog`/
  `fetch_ndbc_catalog` for the public NOAA CO-OPS and NDBC station
  catalogs (metadata used to point sprints 13-15's adapters at *any*
  US coastal coordinate, not just curated locations), degrading to
  `[]` on failure rather than raising — the opposite resilience
  posture from sprint 14's water-temperature/tide-*reading* fetches,
  since a catalog is routing metadata, not a decision-relevant value.
  `nearest_coops_station`/`nearest_ndbc_stations` are pure
  distance-ranking functions over an already-fetched catalog list,
  deliberately decoupled from the fetch/cache layer (the legacy
  module coupled them), so the haversine math is tested with zero
  network mocking. `StationCatalogCache` replaces the legacy module's
  implicit module-level `dict` + `threading.Lock` with an explicit,
  `asyncio.Lock`-based, injectable-clock idempotent TTL cache — a
  positive TTL for a successful fetch, a short negative TTL for a
  degraded one — satisfying the sprint's "provenance, timestamps,
  idempotent refresh" requirement and letting `apps/api/tests/
  test_stations_provider.py` characterize "still fresh, no refetch"
  vs. "expired, refetch and replace" vs. "failed fetch, short
  negative TTL" deterministically instead of sleeping in tests. All
  of `apps/api`'s checks (ruff, ruff format, mypy, pytest — 90
  passed) pass clean.
- This PR continues Phase 2 with **sprint 18** (coastal coordinate
  validation, **complete** using only sprint 17's inputs):
  `apps/api/app/providers/coastal_bounds.py` — `is_valid_coordinate`
  (lat/lng range check) and `classify_coast_region` (a coarse bounding
  box per supported coast — Atlantic, Gulf, Pacific, Alaska, Hawaii —
  both pure and offline, rejecting obviously-wrong input before any
  station lookup is worth doing), plus `gate_coastal_point`, the
  actual inland-rejection mechanism ported from `locations.py`'s
  `_resolve_dynamic_location`/`dynamic_location_for_point`
  (`_DYN_GATE_MILES = 60.0`): a point counts as coastal only if it's
  within `max_miles` of a real CO-OPS or NDBC station in sprint 17's
  catalogs — a bounding box alone can't do inland rejection, since the
  Atlantic-region box necessarily contains the Appalachians. The
  legacy gate's additional curated-location fallback is deliberately
  not ported: it needs the curated-locations dataset, sprint 19's job
  (location resolution), not this one's — so this sprint's gate is a
  strict subset of the legacy gate's inputs, which can only make it
  stricter, never more permissive. `apps/api/tests/
  test_coastal_bounds.py` covers boundary/out-of-range coordinates,
  each of the five supported coast regions by a known city, landlocked
  and far-outside-US rejection, and `gate_coastal_point` against
  synthetic station catalogs (nearer-of-both-catalogs selection,
  custom `max_miles`, empty-catalog handling). All of `apps/api`'s
  checks (ruff, ruff format, mypy, pytest — 105 passed) pass clean.
- This PR continues Phase 2 with **sprint 19** (location resolution,
  **complete**): `apps/api/app/providers/locations.py` — the curated
  101-spot location dataset and dynamic (any-coordinate) location
  resolution, ported from `locations.py`. `app/data/coastal_locations.json`
  and `app/data/water_temps.json` are a **documented mechanical move**:
  generated by `ast.literal_eval`-parsing the legacy module's
  `COASTAL_LOCATIONS`/`_WATER_TEMPS` list/dict literals directly rather
  than hand-transcribed, guaranteeing byte-for-byte fidelity across
  ~1,500 lines of coordinates and station IDs that hand-transcription
  could not credibly promise — the same "documented mechanical move"
  exception to the 400-line guideline sprints 1-3's evidence-acceptance
  PR used. `find_nearest_locations`, `timezone_for_point`,
  `monthly_water_temps_for_region`, `format_dynamic_id`/
  `parse_dynamic_id` (reusing sprint 18's `is_valid_coordinate` instead
  of duplicating the range check), and `resolve_dynamic_location`
  (composing sprint 17's CO-OPS/NDBC catalogs with the curated dataset,
  the direct port of the legacy `_resolve_dynamic_location`) are pure
  functions over already-loaded data, golden-tested in `apps/api/tests/
  test_locations_provider.py` against exact field values for Montauk
  NY, Wrightsville Beach NC (the same fixture coordinates used
  throughout sprints 13-18's tests), and Poipu HI, plus dynamic-point
  resolution near Wrightsville Beach (regional-field inheritance, NWS
  zone inherited within 75mi) and from Kodiak AK (no curated Alaska
  location exists, so nothing inherited, exercising the all-defaults
  path). All of `apps/api`'s checks (ruff, ruff format, mypy, pytest —
  127 passed) pass clean.
- This PR continues Phase 2 with **sprint 20** (observation
  normalization, **complete**): `apps/api/app/domain/normalize.py` —
  wraps sprints 13-15's provider-specific typed outputs (NWS, NOAA
  CO-OPS, NDBC) into `app.domain.models.Observation` (sprint 11's
  ADR-003 canonical vocabulary), a domain-layer concern rather than a
  provider one. Canonical units (`kt` wind, `ft` height, `degF` temp,
  `mb` pressure) were already what every provider emitted since
  sprints 13-15, so this sprint's actual job was consistent labeling
  and typed wrapping, not unit conversion. Deliberately not wrapped:
  astronomy (sprint 16) — computed, not measured, no provenance/
  freshness story to attribute; categorical fields like wind direction
  — no meaningful unit for a `float` value; NWS's marine-zone
  wind/wave data, which is a forecast *range* — collapsed to one
  `ObservationRange` of paired low/high `Observation`s rather than one
  lossily-averaged value, since picking a single representative number
  is an interpretation decision for forecast assembly (sprint 21), not
  this sprint. Every function leaves `is_fallback`/`fallback_reason` at
  their defaults — these are live readings, and deciding when to
  substitute (and mark) a fallback value is forecast-assembly's job,
  as repeatedly deferred there since sprint 14. `apps/api/tests/
  test_normalize.py` covers all three providers' happy paths, `None`
  propagation (a buoy field or NWS range component with no parseable
  source data yields no `Observation`, not an invented one), and that
  the `Observation`/`ObservationRange` provenance fields (provider,
  station/zone, observed_at) are populated correctly. All of
  `apps/api`'s checks (ruff, ruff format, mypy, pytest — 136 passed)
  pass clean.
- This PR continues Phase 2 with **sprint 21** (forecast assembly,
  **complete**): `apps/api/app/domain/assembly.py`'s
  `assemble_forecast` concurrently fans out to NWS marine-zone
  conditions, NOAA CO-OPS water temperature, and NDBC buoy readings
  (each independently fallible, caught individually — one upstream
  failure never blanks the forecast, per the product contract's
  Reliability bullet), plus astronomy (no failure mode given a
  resolved location). Designs `ForecastEnvelope.conditions` — sprint
  11 named sprints 21/22/34/35 as the owners of `conditions`/`tides`/
  `hourly_outlook`/`recommendations`; `tides` is deliberately untouched
  here (a distinct time-series concern, sprint 34's job), and
  `hourly_outlook`/`recommendations` stay opaque too. Each provider's
  normalized output is its own field on `ForecastConditions`, not
  merged into one reconciled value — that reconciliation is forecast
  *scoring*'s job (sprint 22). Water temperature finally gets the
  fallback-to-monthly-average substitution repeatedly deferred to
  "forecast assembly" since sprint 14: when the live CO-OPS fetch
  fails, sprint 19's `monthly_water_temps_for_region` supplies the
  value, labeled via `Observation.is_fallback=True` and
  `fallback_reason` — never presented as a live reading, satisfying
  the product contract's Integrity bullet ("missing observations are
  never turned into invented measurements"). `ForecastState`/
  `Confidence` are intentionally basic (FRESH/PARTIAL from wind-wave
  availability; HIGH/MEDIUM/LOW confidence from source liveness) —
  `ForecastState.STALE` isn't produced (no cache yet, sprint 24's job)
  and the fuller distance/age/fallback confidence-degradation policy is
  sprint 23's job; this sprint only needed something defensible enough
  to react to its own matrix. `apps/api/tests/test_assembly.py`
  exercises the full 2**3 = 8 present/absent matrix across the three
  fallible sources (the sprint's named acceptance criterion), plus
  astronomy-always-present, location-field mapping, and the
  no-stations-assigned edge case. All of `apps/api`'s checks (ruff,
  ruff format, mypy, pytest — 148 passed) pass clean.
- This PR continues Phase 2 with **sprint 22** (forecast scoring,
  **complete**): `apps/api/app/domain/scoring.py`'s `score_conditions`
  — the 0-100 go/no-go index and plain-language explanation, ported
  from the legacy `domain/forecast.py:score_conditions` plus the
  wind-orientation/onshore-offshore-direction mapping from
  `domain/species.py` (`wind_orientation_for_region`/
  `onshore_offshore_dirs`, carried over verbatim per that module's own
  "single authoritative function, do not reimplement elsewhere"
  warning). Deliberately decoupled from sprint 21's
  `ForecastConditions`: it takes an already-reconciled `wind_range`/
  `wave_range` pair (plus optional wind direction, water temperature,
  sun times, and solunar data) as explicit parameters rather than
  reading sprint 21's still-separate NWS/NDBC fields directly —
  picking a source when both report is a future wiring step this
  sprint doesn't own. Scores wind speed, wave height, wind direction
  (onshore/offshore by coastline orientation), water-temperature
  comfort band (with a small bonus for a live, non-fallback reading),
  dawn/dusk light window, and solunar rating/illumination — all
  thresholds, point values, and verdict tiers unchanged from the
  legacy function. Deliberately not ported, each named in the module
  docstring with its blocking dependency: tide state/range/turn-
  proximity bonuses (need tide predictions, sprint 34's job); fishing-
  type-specific modifiers and angler comfort thresholds (need user
  preferences data, sprint 36's job); water-quality/HAB signals from
  `services/datagov.py` (R1's still-open product question — enrichment
  vs. scope creep — re-flagged rather than silently ported or
  dropped). `apps/api/tests/test_scoring.py` characterizes every
  wind/wave threshold band, wind-direction onshore/offshore bonus
  (including Hawaii's deliberate no-op), all four coastline
  orientations via `wind_orientation_for_region`, water-temperature
  comfort bands and the live-vs-fallback bonus, the dawn/dusk window,
  solunar rating/illumination bonuses, verdict-tier boundaries,
  factor-sorted summary generation, and the `wind_range is None or
  wave_range is None` → `Unknown`-verdict early return. All of
  `apps/api`'s checks (ruff, ruff format, mypy, pytest — 203 passed)
  pass clean.
- This PR continues Phase 2 with **sprint 23** (confidence model,
  **complete**): `apps/api/app/domain/confidence.py`'s
  `assess_confidence` has no legacy precedent — the legacy Flask app
  never implemented a confidence concept at all, so this is this
  recovery's own design against `docs/product-definition.md`'s
  Confidence section ("derived from source coverage, observation age,
  station distance, and fallback use"), replacing sprint 21's interim
  HIGH/MEDIUM/LOW-from-liveness stub. Starts at 100 points and applies
  an independent, documented penalty per degrading factor: an
  unavailable/degraded `SourceStatus` per source; an aging/stale
  observation per two age thresholds; a fallback-flagged observation
  (penalized independently of *why* its source is unavailable, per the
  product-definition text treating fallback use as its own axis); and
  a far/very-far station distance (the "far" bound deliberately sits
  inside sprint 18's 60-mile `gate_coastal_point` cutoff — a station
  accepted as "coastal enough to use" can still be too far to fully
  trust). Each penalty reports a plain reason code into
  `Confidence.reasons`, giving the product contract's "always show the
  reasons for reduced confidence" requirement something concrete to
  render. Deliberately decoupled from `app.domain.assembly`, matching
  sprint 22's scoring module's pattern: takes already-computed source
  statuses, observations, and station distances as explicit parameters
  rather than reaching into `ForecastEnvelope`/`ForecastConditions`
  itself — wiring this into `assemble_forecast` in place of its
  interim stub, alongside sprint 22's scoring wiring, remains an
  unassigned follow-up. `apps/api/tests/test_confidence.py` covers
  each factor independently, boundary ages/distances, mutual
  exclusivity within each two-tier band, multiple factors combining on
  one observation and across the whole assessment, and score clamping
  at zero under compounded penalties. All of `apps/api`'s checks
  (ruff, ruff format, mypy, pytest — 226 passed) pass clean.
- This PR continues Phase 2 with **sprint 24** (snapshot caching,
  **complete**): `apps/api/app/infra/snapshot_cache.py`'s
  `SnapshotCache[T]` generalizes sprint 17's `StationCatalogCache[T]`
  (single global value, one TTL) to multiple keys and a two-tier
  freshness policy: `fresh_ttl_seconds` defaults to 4 hours, matching
  the legacy `forecast_cache` cadence the sprint ledger names;
  `stale_ttl_seconds` and the fallback-on-fetch-failure behavior below
  it have no legacy precedent — legacy's cache only ever had "hit" or
  "miss," never a policy for what to serve when a refresh itself
  fails. Built from `docs/product-definition.md`'s Stale-state
  definition ("a previously valid snapshot outside its freshness
  window... still useful as clearly aged fallback information") and
  the product contract's Reliability bullet, extended from "one
  upstream source failing" (sprints 21-23) to "the whole refresh
  failing." A cache entry younger than `fresh_ttl_seconds` is a fresh
  hit (`fetch` never called); between the two TTLs it's a stale hit
  that attempts a refresh; at or past `stale_ttl_seconds` it's evicted
  and behaves exactly like a miss, including that a subsequent fetch
  failure has nothing left to fall back to and propagates; and if a
  refresh fetch raises while a still-eligible entry exists, that entry
  is returned labeled `is_fallback=True` instead of propagating.
  `get_or_refresh` is single-flight per key via a per-key
  `asyncio.Lock` — concurrent callers for the same key share one
  fetch, callers for different keys never block each other. This
  sprint deliberately doesn't replicate legacy's SQLite storage layer
  (no Postgres connection yet, per this README's own "does not yet
  have... a Postgres connection" line) or its background-daemon
  refresh — see the module docstring — and wiring this cache around
  `assemble_forecast`, keyed by location id and producing
  `ForecastState.STALE` on a fallback hit, remains a follow-up
  alongside sprints 22/23's still-unwired scoring/confidence. `apps/api/
  tests/test_snapshot_cache.py` covers fresh hit, stale hit, miss,
  expiry (both successful-refresh and no-fallback-available cases),
  fallback-on-fetch-failure, and single-flight concurrency (same-key
  serialization and different-key non-blocking) independently. All of
  `apps/api`'s checks (ruff, ruff format, mypy, pytest — 241 passed)
  pass clean.
- **CI-health fix (PRs #347/#348, not a numbered sprint): legacy `lint`
  job resolved.** Fixed the ~38 ruff errors, 65 unformatted files, and
  23 mypy errors `docs/R2_CI_BASELINE.md` documented, plus a separate
  workflow bug where mypy crashed on a duplicate `tests` module
  colliding with `apps/api/tests` before it could check anything (fixed
  by excluding `apps/` from the root job's ruff/mypy invocations, since
  `apps/` already has its own dedicated CI). #347's fix passed every
  local check yet the `lint` job still failed post-merge with 580
  errors — root cause: neither the legacy repo-root nor `apps/api` had
  a `pyproject.toml`/`ruff.toml`, so ruff's rule selection silently fell
  back to an undocumented, version-dependent implicit default that
  disagreed between environments even under the same pinned
  `ruff>=0.4,<1.0` constraint. #348 fixed this at the root: an explicit
  repo-root `pyproject.toml` pins `select = ["E4", "E7", "E9", "F"]`
  (the set the cleanup was actually written against), and a separate
  `apps/api/pyproject.toml` (no explicit `select`) stops `apps/api` from
  inheriting that narrower selection while preserving the "clean under
  ruff's implicit default" bar it's held since sprint 12. Verified via
  the GitHub API that both `lint` job runs on #348's merge commit show
  `conclusion: success` — not just a local re-check.
- This PR continues Phase 2 with **sprint 25** (versioned API,
  **complete** except for the two auth-gated endpoints): `apps/api/app/
  api/v1/locations.py` (`GET /v1/locations/search`,
  `POST /v1/locations/resolve`) and `app/api/v1/forecasts.py`
  (`GET /v1/forecasts/{location_id}`,
  `POST /v1/forecasts/{location_id}/refresh`) — 4 of the canonical
  roadmap's 6 required `/v1` endpoints. `GET`/`PATCH /v1/me/preferences`
  are deliberately not attempted: they need Better Auth (sprint 28) and
  a Postgres-backed preferences store, neither of which exists yet — no
  amount of scoping cleverness makes those buildable now. No new domain
  logic: `search`/`resolve` are thin wrappers over sprint 19's location
  functions (plus two small new pure functions,
  `search_curated_locations`/`find_curated_location`), and
  `GET /v1/forecasts/{id}` returns exactly the `ForecastEnvelope`
  sprint 21's `assemble_forecast` already builds — sprints 22-24's
  scoring/confidence/caching refinements remain the unassigned wiring
  follow-up they already were. `refresh` is deliberately identical to
  `GET` today: `assemble_forecast` doesn't cache anything yet (sprint
  24's `SnapshotCache` isn't wired into it), so there's nothing for
  `refresh` to force bypassing until that wiring lands — documented in
  the module docstring rather than silently faked. `app/api/deps.py`'s
  `AppState` (one pooled `BoundedHTTPClient` plus the three sprint-17
  station-catalog caches, created once in `app/main.py`'s FastAPI
  `lifespan`) backs both routers via `Depends`, and its
  `resolve_location_id` helper is shared by both so a location resolved
  explicitly and one resolved implicitly by a forecast lookup always
  agree for the same id. The breaking-change guard
  (`tests/openapi_snapshot.json` + `scripts/generate_openapi_snapshot.py`)
  mirrors sprint 11's domain-model schema-snapshot pattern exactly.
  Verified against a real running `uvicorn` server, not just
  `TestClient`: `/health/live`, `/v1/locations/search`, and
  `/openapi.json` all responded correctly and the live schema matched
  the committed snapshot byte-for-byte. `apps/api/tests/
  test_locations_router.py`/`test_forecasts_router.py` cover search
  matches/no-match/empty-query, resolve-by-id (found and 404),
  resolve-by-point (coastal success and non-coastal 422), malformed
  request bodies, and out-of-range coordinates; forecasts router tests
  cover curated and dynamic location ids, unknown-id 404, non-coastal
  422, and refresh returning the same shape as get. All of `apps/api`'s
  checks (ruff, ruff format, mypy, pytest — 258 passed) pass clean.
- This PR continues Phase 2 with **scoring wiring** (not a numbered
  sprint — the first slice of the "wire sprints 22/23/24 into
  `assemble_forecast`" follow-up sprint 25 named): `app/domain/
  assembly.py` now computes a real `ForecastConditions.score` on every
  forecast via sprint 22's `score_conditions`, closing the gap where
  `GET /v1/forecasts/{id}` returned raw per-source readings but no
  actual go/no-go score. The source-reconciliation policy this
  required — which of NWS's marine-zone range or NDBC's buoy reading
  to score — is now assembly's, documented in its module docstring:
  the marine-zone range is preferred (a genuine forecast low/high
  spread) over the buoy's single live value (used only as a fallback,
  turned into a degenerate zero-width range); wind direction prefers
  NWS's parsed value over the buoy's. Confidence-model and caching
  wiring (sprints 23/24) remain explicitly deferred — `assess_confidence`
  needs real station-distance data `ResolvedLocation` doesn't carry
  yet, named as the concrete blocker rather than left vague. This
  wiring's manual real-server smoke test surfaced a genuine pre-existing
  gap unrelated to scoring: `app/infra/http_client.py`'s
  `BoundedHTTPClient` only caught `httpx.ConnectError`, not the
  broader `httpx.TransportError` family (this sandbox's outbound proxy
  raised `httpx.ProxyError` instead), so a proxy/read/write/pool-timeout
  failure would have escaped as an unhandled exception rather than
  degrading one source gracefully per the product contract's
  Reliability bullet — fixed and characterized in
  `apps/api/tests/test_http_client.py`. New/updated tests in
  `apps/api/tests/test_assembly.py` cover score presence matching the
  FRESH/PARTIAL split, the marine-zone-over-buoy range preference, the
  buoy fallback becoming a zero-width range, and NWS-over-buoy
  direction preference. All of `apps/api`'s checks (ruff, ruff format,
  mypy, pytest — 262 passed) pass clean.
- This PR continues with **confidence wiring** (not a numbered sprint —
  the second slice of sprint 25's named wiring follow-up, closing the
  blocker scoring-wiring's PR named explicitly): `ForecastEnvelope.
  confidence` now comes from sprint 23's `assess_confidence` instead of
  assembly's old liveness-only stub, given per-source status, one
  `AgedObservation` for water temperature (age + fallback), and — for
  dynamic points — a `StationDistance` from a new `ResolvedLocation.
  anchor_miles` field. That field is the plumbing the blocker named:
  `resolve_dynamic_location` (sprint 19) already computed an
  anchor-miles value but discarded it into a tuple `app.api.deps.
  resolve_location_id` (sprint 25) never used; it's now embedded on the
  model itself, `None` for curated locations (they *are* the named
  station — no distance factor) and for points with no anchor found at
  all (an aggregate `float("inf")` in the raw tuple isn't a meaningful
  JSON value). Documented as a deliberate simplification, not a full
  per-source distance breakdown: `resolve_dynamic_location` only ever
  returns the single nearest anchor's distance, not one per fallible
  source. `POST /v1/locations/resolve`'s response schema picked up the
  new field — `tests/openapi_snapshot.json` regenerated, reviewed as a
  one-field additive diff, exactly the deliberate-regeneration flow the
  breaking-change guard exists for. `apps/api/tests/test_assembly.py`'s
  present/absent matrix test now reproduces assembly's exact
  `assess_confidence` inputs to verify the wiring (not re-deriving the
  point arithmetic — `test_confidence.py` already exhaustively covers
  that), plus a new dedicated test confirms a dynamic location's
  `anchor_miles` actually degrades confidence via a
  `distant_station:location:anchor` reason.  Sprint 24's `SnapshotCache`
  remains the one still-unwired piece — it needs a keying/
  `ForecastState.STALE` design decision, not just missing input data,
  see the module docstring. All of `apps/api`'s checks (ruff, ruff
  format, mypy, pytest — 263 passed) pass clean.
- This PR closes the wiring follow-up with **caching wiring** (not a
  numbered sprint — the third and last of the three pieces sprint 25
  named): `app/domain/forecast_cache.py` wraps sprint 21's
  `assemble_forecast` in sprint 24's `SnapshotCache`, keyed by location
  id, *around* assembly rather than inside it — `assemble_forecast`
  stays a pure "assemble one envelope right now" function; caching,
  freshness, and `ForecastState.STALE` labeling are entirely
  `forecast_cache`'s concern. `GET /v1/forecasts/{id}`
  (`get_or_assemble_forecast`) serves a fresh cached envelope when one
  exists; `POST /v1/forecasts/{id}/refresh`
  (`refresh_and_assemble_forecast`) bypasses the freshness check
  entirely and forces a live assemble, repopulating the cache — the
  distinguishing behavior sprint 25's router docstring promised it once
  this landed, finally delivered. `SnapshotCache` gained a
  `force_refresh` method for exactly that, refactored to share
  `get_or_refresh`'s fallback/single-flight logic via a new private
  `_fetch_and_store` helper — externally-observable behavior unchanged,
  confirmed by the existing 15 `SnapshotCache` tests passing unmodified.
  A fallback hit (the wrapped assemble raising) is relabeled
  `ForecastState.STALE`, documented as a **practically dormant path**:
  `assemble_forecast` never raises by design, so normally nothing
  reaches the cache's fallback branch. Both cache-wrapper functions
  accept an injectable `assemble` callable (default: the real one)
  specifically so `apps/api/tests/test_forecast_cache.py` can
  substitute a deliberately failing stand-in and actually exercise that
  dormant path — `assemble_forecast` itself can't be made to raise, so
  a substitutable seam is what makes the path testable at all, the same
  "test the seam directly" approach sprint 24's own tests already take.
  Router-level tests in `test_forecasts_router.py` confirm the wiring
  end-to-end with a call-counting mock transport: a second `GET` never
  re-hits the marine-zone upstream, and `refresh` does even immediately
  after a `GET`. `AppState`/`app.main`'s lifespan gained the cache
  instance; a real running `uvicorn` server was smoke-tested to confirm
  the lifespan wiring boots cleanly. `POST /v1/locations/resolve` and
  `ForecastEnvelope`'s response schemas are unaffected — no OpenAPI
  snapshot regeneration needed, confirmed by the existing snapshot test
  passing unmodified. All of `apps/api`'s checks (ruff, ruff format,
  mypy, pytest — 279 passed) pass clean.
- This PR continues Phase 2 with **sprint 26** (performance budget —
  bounded parallel calls, no duplicates, warm p95 under 750 ms).
  `BoundedHTTPClient` (`app/infra/http_client.py`) now sets `httpx.Limits`
  explicitly (`max_connections`/`max_keepalive_connections`, defaults
  20/10) — despite ADR-003 naming "bounded concurrency" as part of the
  design from the start, the client had silently relied on httpx's own
  unexamined defaults until now, an implementation gap discovered while
  scoping this sprint. **Only takes effect when httpx builds its own
  transport** — a caller-supplied `transport` (every existing test in
  this codebase, via `httpx.MockTransport`) bypasses `limits` entirely;
  `test_http_client.py` characterizes it by constructing a
  no-mock-transport client and inspecting the real transport's
  connection pool's `_max_connections`/`_max_keepalive_connections`, not
  by exercising it through a mock. New `tests/test_performance_budget.py`
  proves the other two acceptance bars: "no duplicates" under genuine
  concurrent HTTP requests (not just the sequential case
  `test_forecasts_router.py` already covered) via `httpx.AsyncClient` +
  `httpx.ASGITransport` driving the real FastAPI app with real
  `asyncio.gather` concurrency — Starlette's synchronous `TestClient`
  can't produce genuine overlapping requests — three concurrent `GET`s
  for the same location produce exactly one upstream marine-zone call,
  proving sprint 24's single-flight caching holds at the HTTP layer
  too, not just the domain layer the caching-wiring PR already tested;
  and "warm p95 under 750ms," measured with real wall-clock timing (no
  fake clock) over 20 already-cached requests, also asserting zero new
  upstream calls occurred (a "warm" request that silently hit the
  network wouldn't be a valid warm-path measurement) — observed p95 ≈
  2.8ms, roughly 270x headroom under budget. This measures the warm
  path's *local* processing latency only: a real end-to-end cold-path
  p95 against live upstreams can't be measured in this sandboxed CI
  environment (`docs/R2_CI_BASELINE.md`'s no-live-provider-dependence
  rule) and isn't part of this sprint's stated acceptance bar, but is
  flagged as open evidence for whenever this runs somewhere with real
  network access. Smoke-tested against a real running `uvicorn` server
  to confirm the new `httpx.Limits` wiring boots cleanly. All of
  `apps/api`'s checks (ruff, ruff format, mypy, pytest — 283 passed)
  pass clean.
- This PR picks up **sprint 13's own deferred gridpoint-wind
  fallback**, now that Phase 2 is otherwise closed out and it's the one
  concrete backend pick needing no new product/infra decisions.
  `apps/api/app/providers/nws.py` gains `fetch_gridpoint_wind`/
  `parse_gridpoint_wind` (`GridpointWindForecast` — wind-only, no wave
  data, since it's a land-point forecast), ported from the legacy
  `_try_nws_gridpoint`, degrading to `None` on failure like
  `fetch_point_alerts` rather than raising like
  `fetch_marine_zone_conditions` — it's a fallback, not a
  decision-relevant primary source. `app/domain/assembly.py` wires it
  in as a *last-resort* wind source: fetched only when neither the
  marine-zone forecast nor the NDBC buoy provide wind, as one extra
  sequential call (deliberately outside the initial `asyncio.gather`)
  rather than on every request — sprint 26's "bounded parallel calls,
  no duplicates" performance-budget discipline applied to the very next
  sprint after landing it. A successful fetch adds a `SourceStatus`
  (`nws:gridpoint_wind`) and a `fallback:gridpoint_wind` warning, feeds
  wind range/direction into scoring (direction only if not already set
  from marine-zone/buoy), and rescues `ForecastState` (FRESH instead of
  PARTIAL). **Documented explicitly, not left as a surprising gap**:
  because the gridpoint forecast never has wave data, it cannot by
  itself rescue `score` — `score_conditions` still needs both wind and
  wave (sprint 22's unchanged contract), so `score` stays
  `None`/`UNKNOWN` whenever wave is unavailable from every source,
  gridpoint included. The legacy module's current-weather observations
  (air temp, humidity, heat index, precipitation) remain deliberately
  deferred: nothing in the required `ForecastConditions` shape names
  them, so porting now would be inventing product scope, not closing a
  named gap. `tests/test_nws_provider.py` gains 8 tests for the new
  parser/fetch functions; `tests/test_assembly.py` gains coverage for
  the present/absent matrix (now explicitly excluding gridpoint via a
  `gridpoint_ok=False` client, preserving its original three-source
  scope, with a fourth conditional `SourceStatus` folded into the
  confidence reproduction for the two now-affected combos), the rescue
  case, the state-vs-score distinction, and proof gridpoint is never
  fetched when marine-zone wind is already available (a mock transport
  that raises on any unexpected `/points/` request, not absence of
  assertions). Confirmed no OpenAPI drift (`ForecastConditions` stays
  opaque inside `ForecastEnvelope.conditions`) and smoke-tested against
  a real running `uvicorn` server. All of `apps/api`'s checks (ruff,
  ruff format, mypy, pytest — 294 passed) pass clean.
- This PR picks up **sprint 14's own deferred CO-OPS wind fallback**,
  right after sprint 13's gridpoint fallback — the two combine into a
  genuine two-step last-resort chain matching the legacy priority
  order exactly. `apps/api/app/providers/noaa_coops.py` gains
  `fetch_coops_wind` (`CoopsWindReading`), ported from the legacy
  `_try_coops_wind` — the latest wind reading from the same CO-OPS
  station already used for water temperature (if that succeeds, this
  is very likely to as well). `app/domain/assembly.py`'s fallback
  chain now tries CO-OPS wind first, then NWS gridpoint wind only if
  that also comes up empty, matching legacy `domain/forecast.py:
  get_marine_conditions`'s exact source order (marine-zone, buoy,
  CO-OPS wind, gridpoint) — stopping as soon as one succeeds, so the
  typical case never pays for either. Same resilience posture as
  gridpoint wind (degrades to `None`, doesn't raise — non-critical
  fallback, not a decision-relevant primary source) and the same
  score-vs-state distinction documented for gridpoint: can rescue
  `ForecastState` to FRESH, can't rescue `score` (neither fallback has
  wave data). A real gap surfaced and fixed along the way: the fallback
  was initially unconditional, meaning a location with no
  `water_temp_station` configured would still fire a pointless network
  call with an empty station id — now guarded exactly like
  `_fetch_water_temp`'s existing empty-station check. Currents
  (`fetch_currents_predictions`/`fetch_currents_observation`),
  environmental metrics (air temp, humidity, visibility, pressure,
  salinity, conductivity), and the tide-chart SVG helper remain
  deliberately deferred: nothing in the required `ForecastConditions`
  shape or `docs/product-definition.md`'s dashboard-hierarchy list
  names tidal currents or these metrics, and SVG rendering isn't a
  provider-adapter concern at all. `tests/test_noaa_coops_provider.py`
  gains 5 tests for the new fetch function (success, no-gust-uses-
  speed, missing-speed/empty-data/provider-error all degrading to
  `None`). `tests/test_assembly.py` gains a `coops_wind_ok` client
  parameter (matching `gridpoint_ok`'s pattern, both defaulting to
  `False` in the present/absent matrix test to preserve its original
  three-source scope, with both fallback `SourceStatus`es folded into
  the confidence reproduction for the two affected combos), a dedicated
  CO-OPS-wind rescue test proving gridpoint is never reached once
  CO-OPS wind already succeeded, and the existing gridpoint tests
  updated to isolate gridpoint's own behavior with
  `coops_wind_ok=False`. Confirmed no OpenAPI drift and smoke-tested
  against a real running `uvicorn` server. All of `apps/api`'s checks
  (ruff, ruff format, mypy, pytest — 300 passed) pass clean.
- **Sprint 44, partial (signed-internal-API verification primitive)**:
  with Phase 2's own sprint-13/14/15 deferred scope essentially exhausted,
  this PR picks up a different, fully-specified piece already decided in
  `docs/architecture.md`'s ADR-004 rather than inventing new scope —
  `app/infra/internal_signature.py` implements the HMAC-SHA-256
  request-signing contract for the Next.js BFF → FastAPI boundary
  (canonical method/path+query/body-digest/user-id/issued-at/expires-at/
  request-id/key-id, constant-time comparison, clock-skew window,
  expiration, and replay detection via an injectable-clock `ReplayGuard`
  that prunes entries at their own `expires_at`, same pattern as
  `SnapshotCache`). `app/api/internal_auth.py` wraps it as a
  constructor-injectable FastAPI dependency (`InternalAuthDependency`)
  that fails closed on missing configuration. Deliberately **not** wired
  onto the `/v1` routers yet: `apps/web` is still the sprint-13 skeleton
  with no signer to pair with it, and a mandatory signature check on
  routes nothing can currently sign would make `apps/api` uncallable by
  its only real client — this is a "build the primitive correctly, wire
  it in later" split, the same pattern sprints 22/23/24 already used
  before their own wiring follow-ups landed. `tests/
  test_internal_signature.py` and `tests/test_internal_auth.py` cover
  both layers: valid signature, tampered body/method/path, expired,
  clock-skew, validity-window-too-long, unknown key id, previous-key
  rotation, replay detection and replay-guard pruning, missing/malformed
  headers, and fail-closed with no configured keys. All of `apps/api`'s
  checks (ruff, ruff format, mypy, pytest — 321 passed) pass clean, no
  OpenAPI drift (nothing wired onto any route yet).
- **Sprint 27, partial (design-system foundation, `apps/web`)**: the
  product owner directed proceeding with Phase 3 frontend work under the
  placeholder identity rather than waiting on a final branding decision
  (name/visual identity still not decided — "Surf & Pier Forecast"
  remains explicitly provisional throughout). `apps/web/app/globals.css`
  adds Tailwind v4 via `@theme`-declared design tokens (colors, radius,
  font) for light and dark, starting from `v2/frontend/src/index.css`'s
  teal/coral palette -- `docs/R1_RECONCILIATION_AUDIT.md` §3.2 flagged
  that app's `.button`/`.card`/`.field` *global CSS classes* as Replace
  ("not a real design system"), not its color choices, so the palette
  carries forward while the component layer is rebuilt as real React
  primitives. `app/components/ui/` gained `Button` (renders a real
  Next.js `<Link>` when `href` is given, a native `<button>` otherwise;
  visible focus ring), `Card`, `Badge` (a status pill for sprint 32's
  go/no-go traffic-light headline -- color reinforces the verdict, the
  verdict itself is always the visible text label, never color alone),
  `Field` (label/hint/error wired together via `aria-describedby`/
  `aria-invalid`, closing the `.field`-class accessibility gap §3.6
  flagged), and `Container` (mobile-first responsive width). `app/page.tsx`
  is now a gallery page showcasing all five at phone and desktop widths,
  screenshotted in both color schemes via a headless Chromium smoke test
  (no console/page errors besides the pre-existing, unrelated favicon
  404 every un-favicon'd Next.js app skeleton has). `app/not-found.tsx`
  is the trivial 404 page R1's §3.1 route table names as a straight
  `Keep`. Deliberately not attempted here: i18n-ready string
  externalization (bundled into sprint 27 by R1's §3.7 disposition) and
  a formal WCAG 2.2 AA audit (axe + keyboard/screen-reader evidence,
  explicitly sprint 40's job per §3.6) -- this PR aims for
  accessible-by-construction markup (semantic landmarks, labeled/
  described form controls, visible focus states, text-not-color status
  labels), not a certified audit. `npm run lint` (oxlint) and
  `npm run build` both pass clean; TypeScript strict-mode compiles with
  no errors.
- **Sprint 44's signed-internal-API wired end-to-end, plus a live
  `apps/web` → `apps/api` proof**: with sprint 27's design-system
  primitives in place and sprint 44's verification primitive already
  built (previous PR), the two obvious blockers to actually wiring
  ADR-004's signature requirement were both gone -- so this PR does
  both halves at once rather than leaving the requirement unsatisfiable.
  `apps/api/app/api/v1/locations.py`/`forecasts.py` now require
  `require_internal_signature` on every route
  (`dependencies=[Depends(...)]`); every existing router test overrides
  it to a no-op (matching `get_app_state`'s established pattern) since
  those files are about router/domain behavior, not signature
  verification -- a new `tests/test_internal_api_wiring.py` is the one
  file that deliberately does *not* override it, proving against the
  real app that an unsigned request is rejected (401), a correctly
  signed one succeeds (200), and no configured keys fails closed (500).
  `apps/web/lib/internal-signature.ts` is a byte-for-byte TypeScript
  mirror of the Python primitive's canonical-string algorithm (same
  field order, same delimiter, same HMAC-SHA-256); `lib/
  internal-api-client.ts`'s `internalApiFetch` signs and sends requests
  with it, throwing rather than silently calling unsigned if the
  signing-key env vars are missing. `apps/web/app/forecast/demo/page.tsx`
  (`export const dynamic = 'force-dynamic'` -- forecasts are per-request
  live data, and Next.js 16's static-shell prerendering would otherwise
  freeze a build-time fetch failure into what every visitor sees) is a
  Server Component proving the whole chain end-to-end for a fixed demo
  location (Wrightsville Beach, NC). Verified against two real running
  servers with matching dev signing keys, not just mocked unit tests: an
  unsigned `curl` to `apps/api` got a real 401, and the demo page
  rendered a real, correctly-signed, gracefully degraded forecast (state
  `partial`, confidence `low`, real "could not connect to
  api.weather.gov/ndbc.noaa.gov" warning messages -- upstream calls are
  blocked in this sandbox per `docs/R2_CI_BASELINE.md`) in about 8.5
  seconds. `user_id` stays empty on every signed request for now --
  there's no Better Auth (sprint 28) session yet to source a real one
  from. All of `apps/api`'s checks (ruff, ruff format, mypy, pytest --
  324 passed) and `apps/web`'s (`npm run lint`, `npm run build`) pass
  clean.
- **Sprint 31, partial (text location search)**: the natural next step
  once the signed BFF path could reach a real endpoint. `apps/web/app/
  components/location-search.tsx` is a hand-rolled WAI-ARIA combobox (no
  dependency) calling a new `app/api/locations/search/route.ts` -- a
  Route Handler proxying apps/api's `GET /v1/locations/search` through
  `internalApiFetch`, the one place a Client Component's `fetch` can
  land since the signing secret is server-only and the browser must
  never call apps/api directly (ADR-004). This is this app's first
  genuinely interactive (Client Component) UI, so it's verified with
  headless Chromium actually typing into the input, not just curl:
  typed "wrights", saw exactly one real matching result
  ("Wrightsville Beach, NC"), arrow-keyed to it, pressed Enter, and saw
  the selection render with its real id/coordinates; a separate run
  confirmed the distinct no-matches state renders correctly too.
  Demonstrated on `app/locations/page.tsx`. Deliberately not attempted:
  device geolocation, map search, and station-preview/ambiguity states
  -- text search alone is already a complete, useful capability, and
  each of those is its own sizeable UI. `npm run lint` picked up one new
  warning (`react/set-state-in-effect` on the debounced-fetch effect) --
  a known false-positive class for async data-fetching-in-effect
  patterns, non-blocking (same as `layout.tsx`'s two pre-existing
  `metadata`/`viewport`-export warnings), left as-is rather than
  contorted around a rule that doesn't cleanly apply here.
- **Sprint 31's search wired into a real forecast lookup, retiring the
  fixed demo page**: the natural next increment now that search exists.
  `apps/web/app/forecast/[locationId]/page.tsx` replaces the earlier
  `/forecast/demo` (which only ever showed Wrightsville Beach) with a
  real per-location lookup for any `location_id` apps/api recognizes;
  an unknown id 404s via Next's own `notFound()` rather than rendering
  a confusing error card. The forecast-rendering markup itself moved
  into a shared `app/components/forecast-card.tsx` (`ForecastCard`/
  `ForecastErrorCard`) so there's one place it's implemented, not one
  per page. `/forecast/demo` still resolves -- it's now a one-line
  redirect to `/forecast/wrightsville-beach-nc`, kept rather than
  deleted in case anything still links there. `app/locations/page.tsx`
  gained a "View forecast" button on a selected search result, linking
  straight to its `/forecast/{id}` page -- search and forecast stay
  separate pages/concerns, joined by a plain navigation link.
  `lib/internal-api-client.ts`'s `InternalApiError` is now exported so
  the forecast page can distinguish a 404 (unknown location) from any
  other failure. Verified with the full interactive flow end-to-end via
  headless Chromium against two real running servers: typed a query in
  `/locations`, selected the one real result, clicked "View forecast,"
  landed on `/forecast/wrightsville-beach-nc`, and saw a real,
  gracefully degraded forecast render -- plus direct-curl checks that
  the demo redirect 307s correctly and an unknown location 404s.
  `npm run lint` and `npm run build` both pass clean (same one
  pre-existing `react/set-state-in-effect` warning as before, no new
  ones).
- **Sprint 34, partial (tide predictions, backend half)**: with search
  and per-location forecast lookup both working end-to-end, tide data
  was the next concrete gap in what a real forecast lookup actually
  returns -- `ForecastEnvelope.tides` had been `None` since sprint 21
  deliberately deferred it. `app/domain/assembly.py` now fetches tide
  predictions (`app.providers.noaa_coops.fetch_tide_predictions`,
  already built in an earlier sprint, unused until now) in the same
  `asyncio.gather` as the marine-zone/water-temp/buoy/alerts fetches --
  independent and parallel, not sequential, per sprint 26's discipline.
  The request window is today through two days out, computed in the
  *location's own timezone* (`app.infra.timezones.safe_zone`) rather
  than a naive UTC date, which could be off by a day for locations far
  from UTC. `ForecastTides` (station id + upcoming high/low
  predictions) is the sprint-34-owned shape of `tides`, mirroring how
  sprint 21 owned `conditions` and sprint 22 owned `score`. On failure,
  `tides` stays `None` with an advisory `Warning` -- there's no
  fallback substitute for tide predictions the way water temperature
  has a monthly climatological average, so "unavailable" is the honest
  answer, never invented. `tests/test_assembly.py` gained a
  `tides_ok` parameter (matching `coops_wind_ok`/`gridpoint_ok`'s
  established pattern) and every existing inline mock handler in that
  file needed a `product=predictions` branch added, since tide
  request URLs also match the generic `datagetter` substring check
  used for water-temperature -- without the explicit branch, tide
  fetches would have silently received water-temperature JSON and
  degraded via a real (if accidental) error path rather than the
  intended one. Three tests are new: presence, the local-date-window
  computation (asserting the exact `begin_date`/`end_date` in the
  outgoing request URL), and degrade-on-failure. Verified against a
  real running server, not just mocked tests: the `noaa_coops:tides`
  source correctly reports `unavailable` with a genuine "could not
  connect to api.tidesandcurrents.noaa.gov" detail in this sandboxed
  environment (upstream calls are blocked per
  `docs/R2_CI_BASELINE.md`), proving the degrade-gracefully path
  end-to-end. Deliberately not attempted: accessible chart rendering
  and text alternatives -- the frontend half of sprint 34's acceptance
  bar, and `apps/web` doesn't render `tides` at all yet. All of
  `apps/api`'s checks (ruff, ruff format, mypy, pytest -- 326 passed)
  pass clean.
- **Sprint 34's frontend half: rendering tides on the forecast page**:
  the natural continuation now that `apps/api` actually returns tide
  data (previous PR). `apps/web/app/components/forecast-card.tsx`'s
  `ForecastCard` gained a `TideTable`, rendered when `forecast.tides`
  is present -- a plain, properly-labeled `<table>` (`<caption>`,
  `scope="col"` headers) rather than a visual chart, which is itself an
  accessible representation of the data, not a lesser fallback for a
  chart. This closes sprint 34's "text alternatives" acceptance
  sub-item; the "accessible charts" sub-item (an actual visual chart)
  is not attempted. Times are formatted in the *location's* timezone
  (`Intl.DateTimeFormat` with `forecast.location.timezone`), not the
  viewer's browser timezone -- a tide time is only meaningful relative
  to the place it's for, and the two can differ. Since this sandbox's
  blocked upstream calls mean `tides` is always `None` on the real
  live path (verified in the previous PR), the table's actual rendering
  couldn't be exercised through a real request here -- it was instead
  visually verified against realistic mock data (four tide events
  spanning two days, matching the real API shape) via a temporary
  preview page under `app/forecast/`, screenshotted in both light and
  dark themes, then deleted before committing so it never shipped.
  `npm run lint` and `npm run build` both pass clean (same warnings as
  before, no new ones).
- **`axe-core` spot-check across every real `apps/web` page, two real
  bugs found and fixed** (verification of already-shipped work, not
  new sprint scope -- sprint 40's formal WCAG 2.2 AA audit remains
  unattempted): ran `axe-core` (fetched into a scratch npm project, not
  committed as a dependency -- this was a one-time verification pass,
  not new permanent CI infrastructure, which would be its own
  deliberate decision) against `/`, `/locations`, `/forecast/{id}`,
  and the 404 page, in both light and dark, plus two dynamic states
  (the location-search dropdown open, the gallery's error `Field`
  visible). Found: (1) `--color-nogo-text` used directly on the page
  background failed WCAG AA contrast in dark mode (2.6:1 of a required
  4.5:1) in `Field`'s error message and `ForecastErrorCard` -- that
  token is correctly theme-invariant for `Badge`'s own pill (paired
  with an equally theme-invariant background, so never actually
  broken there), but bare status text on the alternating page
  background needed its own token; added `--color-danger-text` with a
  proper dark-mode override and migrated both call sites. (2)
  `LocationSearch`'s dropdown used `<ul>`/`<li role="option">`, which
  breaks ARIA's required-owned-elements relationship -- overriding an
  `<li>`'s implicit "listitem" role to "option" means axe no longer
  sees the `<ul>` as containing real list items, tripping
  `aria-required-children`/`aria-required-parent`/`list` simultaneously;
  switched to plain `<div role="listbox">`/`<div role="option">`,
  which carry no conflicting implicit role -- the standard fix for
  this well-known interaction. Zero violations across every page and
  state after both fixes, confirmed with a full re-run; the
  search-to-forecast interactive flow (type, arrow-key, select,
  navigate) was re-verified functionally unchanged after the markup
  change. `npm run lint`/`npm run build` both pass clean.
- **Sprint 33, partial (source-attributed snapshots)**: the natural
  next increment after the accessibility spot-check -- the forecast
  page already showed the aggregate `state`/`confidence`/`warnings`,
  but not a per-source breakdown, exactly sprint 33's stated bar.
  `ForecastCard` (`apps/web/app/components/forecast-card.tsx`) now
  renders `forecast.state` as a `Badge` (fresh/stale/partial/
  unavailable, apps/api's own `ForecastState` vocabulary, not
  reinterpreted) instead of plain text, and a new `SourceStatusList`
  lists every source apps/api fanned out to -- marine zone, water
  temperature, buoy, tides, and the wind-fallback chain when it fires
  -- each with a human-readable provider label, an ok/degraded/
  unavailable `Badge`, and the raw provider error shown as its own
  line for non-ok sources (the honest "why" behind a bad badge).
  Verified against a real running server: every source correctly shows
  `unavailable` with its real connection-error detail in this sandbox,
  exactly as designed, not a bug. Re-audited with `axe-core` after the
  change -- zero violations -- and in the process caught one more real
  bug: the source-detail and warning message text (which can contain
  long provider URLs) overflowed the page's width at phone viewport
  size instead of wrapping, breaking the mobile-first layout;
  `break-words` on those three text nodes fixed it, confirmed by
  re-screenshotting at 390px before and after. `npm run lint`/
  `npm run build` both pass clean.
- **Sprint 34, continued (hourly outlook -- the remaining "timing"
  scope)**: `apps/api/app/domain/timing.py`'s `build_hourly_outlook`
  ports the legacy `domain/forecast.py:build_activity_timeline` -- a
  24-hour, one-value-per-hour fish-activity estimate combining
  dawn/dusk, solunar major/minor bands, tide-change windows, a
  night-hours penalty (partially offset by a bright-moon nocturnal
  boost), and a wind-conditions activity ceiling -- as an *adapt*, not
  a verbatim carry-over: it consumes this recovery's own typed inputs
  (`SunTimes`/`SolunarTimes`, the tide predictions
  `app.domain.assembly` already fetches, and the already-reconciled
  wind range) instead of re-parsing legacy's pre-formatted strings, and
  its wind thresholds are converted from mph to this recovery's
  canonical kt unit. `ForecastEnvelope.hourly_outlook` is now populated
  on every request -- unlike `tides`, it never degrades to `None`,
  since astronomy is pure computation and both tide predictions and
  wind range are already-optional inputs the function tolerates being
  absent. Deliberately not ported: the barometric-pressure-trend
  multiplier (no typed pressure-trend data exists yet, deferred to
  sprint 35) and `build_best_times`'s labeled-window summary (a
  separate legacy function needing sprint 36's user-preferences data
  for its bridge/jetty and preferred-time/tide-preference boosts) --
  see the module docstring for the full accounting. `apps/api/tests/
  test_timing.py` (18 tests) characterizes dawn/dusk boosting,
  major-vs-minor solunar banding (a minor period never downgrades an
  overlapping major one), reason deduplication, bright-moon boosting,
  high-vs-low tide boost magnitude, same-day-only tide filtering,
  wind-conditions damping, and the is-now/peak flags. Verified against
  the real `/v1/forecasts/{id}` endpoint, not just the unit tests: with
  every live upstream blocked in this sandbox, `hourly_outlook` still
  comes back fully populated with real dawn/solunar reasoning (hour 6
  tagged `prime`, reasons `["Dawn", "Minor solunar"]`, `peak: true`),
  proving the "astronomy always resolves" claim end-to-end, not just in
  mocked tests. All of `apps/api`'s checks (ruff, ruff format, mypy,
  pytest -- 344 passed) pass clean. `hourly_outlook`'s own
  accessible-chart/text-alternative frontend rendering (`apps/web`'s
  job, matching sprint 34's tides split) is not attempted here.
- **Sprint 34, frontend half of the "timing" scope**:
  `apps/web/app/components/forecast-card.tsx` gains
  `HourlyOutlookTable`, rendered when `forecast.hourly_outlook` is
  present -- the same text-alternative-not-a-chart approach as
  `TideTable` (a plain, `<caption>`/`scope="col"`-labeled `<table>`),
  with the current hour highlighted, an `Activity` `Badge`
  (prime/high -> go, med -> marginal, low -> neutral, so a quiet
  overnight hour never reads as a failure state), and a `Why` column
  showing apps/api's own plain-language reasons verbatim. Unlike
  `tides`, `hourly_outlook` never degrades to `None` (astronomy always
  resolves) -- so unlike `TideTable`'s mock-data verification, this was
  checked against the real, live `/forecast/wrightsville-beach-nc`
  page: real dawn/dusk/solunar reasoning rendered correctly (hour 6
  tagged `Prime · Peak`, `Dawn · Minor solunar`), and a fresh
  `axe-core` spot-check across desktop/phone x light/dark (4
  combinations) found zero violations and no horizontal overflow at
  390px. `npm run lint`/`npm run build` both pass clean. A visual chart
  and sprint 32's "best window" dashboard headline built from this data
  remain open follow-ups, not attempted here.
- **Sprint 32, partial (dashboard hierarchy)**: restructures the
  existing single-location forecast page, not the multi-location
  dashboard (that needs sprint 37's saved locations first).
  `apps/web/app/components/forecast-card.tsx`'s `ForecastCard` now
  matches the sprint's acceptance bar -- "go/no-go as a simple
  traffic-light headline (score/narrative expandable, not primary);
  best window, conditions, confidence, freshness first": the verdict
  `Badge` is enlarged and first, a new `deriveBestWindow` pure function
  derives a "best window" callout straight from `hourly_outlook` (the
  longest contiguous run of the day's best activity tag -- no new
  fetch, exactly what sprint 34's own module docstring flagged as
  derivable later), and the numeric score plus its narrative move into
  a native `<details>`/`<summary>` -- present, but demoted.
  Confidence/state/freshness stay in the summary strip right below. A
  wind/wave/water-temperature "conditions" mini-panel is a deliberate
  follow-up, not this PR: `apps/api`'s `ForecastConditions` only
  carries per-source wind/wave (`marine_zone_wind`/`buoy`), not an
  already-reconciled single range, and re-deriving that reconciliation
  policy on the frontend would duplicate -- and risk drifting from --
  `app.domain.assembly`'s own `_reconcile_range`, which already decided
  it once for scoring. Since this sandbox's blocked upstream calls mean
  the verdict is always `Unknown` (empty score/summary) on the live
  path, the enlarged traffic-light badge and the expandable
  score-details interaction were verified against a temporary mock
  preview page (a `Good`/82 verdict with a real best-window block;
  screenshotted collapsed and -- via a real Playwright click on the
  `<summary>` -- expanded, in both color schemes, then deleted before
  committing); a fresh `axe-core` spot-check on both the live page and
  the mock preview found zero violations and no horizontal overflow at
  390px. `npm run lint`/`npm run build` both pass clean.
- **Sprint 32, continued (the "conditions" mini-panel)**: backend,
  `apps/api/app/domain/assembly.py`'s `ForecastConditions` gains
  `wind_range_kt`/`wave_range_ft`/`wind_direction` -- the exact
  already-reconciled wind/wave range and direction `score_conditions`
  was computed from (including the last-resort wind-fallback-chain
  result, when it fires), exposed as their own fields instead of only
  living as local variables, so a frontend summary can show the same
  numbers the go/no-go score used rather than re-deriving this
  module's NWS-marine-zone-over-NDBC-buoy source-preference policy a
  second time. `apps/api/tests/test_assembly.py` extends four existing
  tests (marine-zone-preferred, buoy-fallback, direction-preference,
  gridpoint-wind-rescue) with exact-value assertions on the new
  fields, plus a presence assertion in the present/absent matrix,
  rather than adding parallel duplicate tests -- 344 passed; ruff,
  ruff format, and mypy all clean. Frontend: `apps/web/app/components/
  forecast-card.tsx` gains `ConditionsSummary`, rendered right after
  the "best window" callout per the acceptance bar's literal ordering,
  showing one line (e.g. "Wind 10-15 kt SW · Waves 2-3 ft · Water
  76°F") from those same three fields; water temperature (always
  present, unlike wind/wave) is labeled "(monthly avg)" when
  `is_fallback` is set. Verified against the real, live forecast page
  (correctly shows only the water-temperature line when wind/wave are
  `null`, this sandbox's actual state) plus two temporary mock preview
  pages -- one with a full wind/wave/water-temp reading, one exercising
  the water-temperature-fallback label -- screenshotted and
  `axe-core`-checked in both color schemes (zero violations, no
  overflow), then deleted before committing. `npm run lint`/`npm run
  build` both pass clean. This closes out sprint 32's named elements on
  the single-location page; only the multi-location dashboard itself
  (sprint 37) remains open.
- **Sprint 44, continued (CSP and security headers)**:
  `apps/web/next.config.ts`'s `headers()` now attaches a self-only
  `Content-Security-Policy` (`default-src 'self'`, every directive
  scoped to `'self'`, `'unsafe-inline'` only on `script-src`/`style-src`
  since Next.js inlines its hydration payload without a nonce) plus
  `X-Content-Type-Options`/`X-Frame-Options`/`Referrer-Policy`/
  `Permissions-Policy`/`X-Permitted-Cross-Domain-Policies`/
  `Strict-Transport-Security` to every response, and `poweredByHeader:
  false` drops `X-Powered-By: Next.js`. Adapted from the legacy Flask
  app's `_set_security_headers` (`app.py`), not ported verbatim: this
  CSP is deliberately stricter than the legacy one since apps/web has
  no third-party scripts, external fonts, or non-`self` image origins
  to allow-list yet, and `Permissions-Policy` locks geolocation/camera
  fully closed (the legacy app scoped them `self` for features apps/web
  doesn't have yet). Nonce-based CSP was considered and deliberately
  not used -- it would force *every* page to render dynamically (per
  `node_modules/next/dist/docs/01-app/02-guides/
  content-security-policy.md`'s "Without Nonces" section), a real
  static-rendering cost not worth paying for pages with no user data;
  this doc also surfaced one of `apps/web/AGENTS.md`'s warned breaking
  changes firsthand -- this Next version renamed the nonce-generating
  file from `middleware.ts` to `proxy.ts`. Verified against a real
  production build (`next build && next start`, not `next dev`):
  `curl -D -` confirmed every header on a static page, a dynamic page,
  and a Route Handler; a headless-Chromium pass drove the full
  search-select-navigate interactive flow end-to-end and confirmed
  **zero actual CSP violations** (an initial "404 Failed to load
  resource" console message turned out to be Next's own `Link`
  prefetch aborting when a real navigation supersedes it -- normal
  behavior, reproduced identically on `main` without this change, not
  a regression); a fresh `axe-core` spot-check across four real pages
  found zero violations. `npm run build`'s route table is unchanged
  (`headers()` doesn't force static pages dynamic) and `npm run lint`
  is clean. CSRF and brute-force defense (sprint 44's remaining pieces)
  are not attempted -- both need Better Auth (sprint 28) first, since
  neither is meaningful before there are mutating, authenticated
  endpoints to protect.
- **Sprint 39, partial (Lighthouse)**: ran a real Lighthouse audit
  (mobile, performance/accessibility/best-practices/SEO) against a real
  production build (`next build && next start`, not `next dev`) for
  `/`, `/locations`, and `/forecast/wrightsville-beach-nc` -- this
  repo's first Lighthouse run, distinct from the `axe-core` spot-checks
  used so far (which only cover accessibility). Accessibility,
  best-practices, and SEO all scored a clean 100 on every page;
  performance scored 96-98. One genuine finding, fixed: no
  `favicon`/`icon` file existed anywhere in `apps/web`, so every page
  load made a real browser request for `/favicon.ico` that 404'd -- a
  real logged console error (Lighthouse's `errors-in-console` audit
  failed outright, 0/1). `apps/web/app/icon.tsx` generates a real 32x32
  PNG at build time via `next/og`'s `ImageResponse` (statically
  optimized, no `public/` asset needed) -- a small wave glyph using
  `app/globals.css`'s own teal/coral design-system palette, not an
  arbitrary color, so this implies no branding decision beyond the one
  already on record (sprint 27's row). Confirmed fixed: `best-practices`
  went from 96 to 100 on the forecast page after adding it; `curl`/
  `file` confirmed a real `image/png` response. The remaining
  performance-timing audits (`total-blocking-time`,
  `max-potential-fid`, `unused-javascript` -- flagging ~55 KiB inside
  Next.js/React's own framework chunks, not identifiable app code) are
  recorded as a real baseline, not chased: this sandbox's shared,
  unaccelerated CPU makes absolute timing numbers noisy run-to-run (the
  same page scored both 94 and 98 across two runs), the same caveat
  sprint 26's performance-budget test already documented for cold-path
  latency -- further bundle-splitting work would be premature before
  Phase 3 itself is complete. Layout shift, tap targets, and
  screenshot budgets (the sprint's other named sub-items) are not
  attempted. `npm run lint`/`npm run build` both pass clean, route
  table unchanged except the new static `/icon` route.
- **Sprint 34, the hourly-outlook "accessible charts" sub-item**:
  `apps/web/app/components/forecast-card.tsx` gains
  `HourlyOutlookChart`, a hand-rolled SVG bar chart rendered alongside
  (not instead of) the already-complete `HourlyOutlookTable`. Per the
  `dataviz` skill's own form heuristic, one activity level per hour is
  a **magnitude** series, not a categorical identity, so it gets a
  single-hue sequential encoding -- `--color-primary` at variable
  opacity, bar height *and* opacity both tracking `level` -- rather
  than four discrete colors for `ActivityTag`'s tiers.
  `--color-go-text`/`--color-marginal-text` were considered and
  rejected for the bar fill: those tokens are theme-invariant, tuned
  only for pairing with their own light-tint badge background, and
  would risk the exact dark-mode contrast bug the sprint-27 `axe-core`
  pass already found and fixed once for `--color-nogo-text` --
  `--color-primary`/`--color-accent` are already theme-aware, so
  reusing them sidesteps that risk instead of adding new tokens to
  re-solve it. The current hour gets an accent ring; the day's peak
  gets an accent dot. The whole chart is `aria-hidden="true"` -- a
  decorative duplicate of data the table already carries as real,
  screen-reader-reachable text, so re-announcing it would be noise,
  not a service; each bar has a native SVG `<title>` (mouse-hover
  tooltip) but no `tabindex`, since an `aria-hidden` subtree must
  never contain a keyboard-focusable element (axe-core's
  `aria-hidden-focus` rule). Since `hourly_outlook` never degrades to
  `None` (unlike `tides`), this was verified against the real, live
  forecast page -- the chart's bar heights visibly match the adjacent
  table's levels -- plus a fresh `axe-core` spot-check across
  desktop/phone x light/dark (4 combinations), zero violations, no
  overflow. `npm run lint`/`npm run build` both pass clean. This
  closes the "accessible charts" half of sprint 34's acceptance bar
  for the hourly outlook; only a tide visual chart (a smaller
  follow-up -- a curve/point chart for a handful of high/low events,
  not a bar chart) remains open.
- **Sprint 34 complete: the tide visual chart, the sprint's last
  remaining open piece.** `apps/web/app/components/forecast-card.tsx`
  gains `TideChart`, rendered alongside (not instead of) the
  already-complete `TideTable`. Deliberately a **point chart with
  straight lines between real predictions, not an interpolated
  curve**: NOAA CO-OPS's `hilo` predictions product gives real
  predicted heights only at each high/low extremum, not a continuous
  hourly series, so a smooth cosine-shaped curve between them would be
  *inventing* the in-between shape rather than showing real predicted
  values -- the same Integrity discipline this recovery already
  enforces server-side (e.g. `is_fallback` labeling) applied to a
  frontend chart choice. A small point count (typically 4-6 across the
  2-day fetch window) means every point gets its own direct height
  label -- `dataviz`'s "label selectively" guidance explicitly allows
  labeling every point when there are only a handful, unlike the
  24-bar hourly chart's sparser labeling. Single-hue on
  `--color-primary` (a magnitude series, not identity -- same
  reasoning as `HourlyOutlookChart`), `aria-hidden="true"`, no
  `tabindex` inside it. The x-axis is real elapsed time between the
  first and last prediction, not evenly-spaced-by-index, since
  predictions can span more than one day unevenly. Caught and fixed
  one real rendering bug in the process: the first/last point's
  centered height label was clipped by the `viewBox` edge with zero
  horizontal padding -- added side padding and confirmed both edge
  labels fully visible in a re-screenshot. Since `tides` is always
  `None` on this sandbox's live path, verified against a temporary
  mock preview page (six realistic alternating high/low predictions;
  screenshotted in both color schemes at desktop and phone widths,
  then deleted before committing) plus a fresh `axe-core` spot-check
  -- zero violations, no overflow. `npm run lint`/`npm run build` both
  pass clean. **This closes sprint 34's acceptance bar entirely** --
  accessible charts, text alternatives, and timezone/DST tests are all
  done for both tides and the hourly outlook.
- **Sprint 49, partial (SEO and sharing -- "public non-personal
  forecast pages" half)**: `apps/web/app/forecast/[locationId]/
  page.tsx` gains a real `generateMetadata` -- per-location title
  (`"{label} Fishing Forecast"`), description, canonical URL, and
  OpenGraph tags, replacing the root layout's generic default on the
  one page type worth indexing individually. The description is
  deliberately static copy about the location, never live score/
  warning text -- a degraded-conditions sentence (a real "could not
  connect to..." warning) has no business being cached into a search
  result or link-preview card. The actual `internalApiFetch` call was
  wrapped in React's `cache()`, intended to make `generateMetadata` and
  the page body share one real network round trip per request instead
  of two (`fetch`'s own automatic per-request memoization can't help
  here regardless -- ADR-004 signs every request with a fresh
  `requestId`/timestamp, so two calls for the same location never look
  like the same `fetch(...)` call to that mechanism). **Correction,
  logged in sprint 41's row below**: this was later found, once
  request tracing existed to check it, not to actually work -- two
  distinct signed calls reach apps/api per page view, not one. A 404
  (unknown `location_id`) calls `notFound()` from `generateMetadata`
  too, matching the page body, so a bad link gets Next's real
  not-found metadata instead of a fabricated title.

  `app/layout.tsx` gains `metadataBase` (env-driven via
  `NEXT_PUBLIC_SITE_URL`, defaulting to `http://localhost:3000`), a
  title template, and `openGraph`/`twitter` defaults.
  `app/opengraph-image.tsx` generates a real 1200x630 PNG link-preview
  card at build time via `next/og`'s `ImageResponse` (same technique
  as `app/icon.tsx`'s favicon), using the design system's own
  teal/coral palette -- no new branding decision; a per-location card
  is a follow-up. `app/robots.ts` allows every page (nothing private
  exists yet -- sprint 28's job) and deliberately omits a `Sitemap`
  directive: a real sitemap needs an endpoint that can enumerate every
  curated location, and `apps/api`'s 101-spot dataset isn't exposed
  that way today (only via `/v1/locations/search`'s query-based
  lookup) -- inventing a partial sitemap from whatever happens to be
  searchable would misrepresent the site's real page count more than
  omitting it entirely; that's this sprint's remaining open piece,
  needing a small `apps/api` addition first, alongside the "private
  dashboards" half (needs sprint 28's auth).

  Verified against two real running servers: `curl` confirmed the real
  per-location `<title>`/description/canonical/`og:*` tags, the 404
  page's fallback to the generic title, `robots.txt`'s real output,
  and the OG image's real `image/png` response (`file` confirmed
  1200x630). A fresh `axe-core` spot-check on the forecast and home
  pages found zero violations. `npm run build`'s route table gained
  `/robots.txt` and `/opengraph-image` as new static routes;
  `/forecast/[locationId]` is still `ƒ Dynamic`. `npm run lint`/
  `npm run build` both pass clean.
- **Sprint 41, partial (structured observability -- the dependency-free
  half)**: `apps/api/app/infra/request_logging.py`'s `log_requests`
  middleware emits one structured JSON trace line per request
  (`request_id`/method/path/status_code/duration_ms -- "safe context,"
  no query string, headers, or body), correlated with
  `apps/web/lib/internal-api-client.ts`'s own trace line for the same
  call via ADR-004's `X-Internal-Request-Id` header, already generated
  for signing rather than a new correlation scheme invented here.
  Fires even for a request that never reaches a route handler (an
  unsigned/unauthenticated call rejected by
  `require_internal_signature`), since Starlette middleware wraps the
  whole ASGI call, not just the routes behind that dependency --
  `apps/api/tests/test_request_logging.py` proves this explicitly, not
  just the happy path.

  Caught and fixed a real bug in the process: the middleware's
  `logger.info(...)` calls were silently dropped under a real
  `uvicorn app.main:app` run -- no handler was ever attached to the
  `app.request` logger (uvicorn's own logging config only wires up its
  own `uvicorn`/`uvicorn.access`/`uvicorn.error` loggers, and nothing
  else in this app calls `logging.basicConfig()`), while pytest's
  `caplog` fixture had been masking this the whole time by attaching
  its own handler to the root logger regardless of this logger's own
  configuration -- exactly the "tests pass, runtime is silent" pattern
  this session's discipline of checking a real running server, not
  just unit tests, exists to catch. Fixed by giving the logger its own
  `StreamHandler(sys.stdout)`, deliberately leaving `propagate` at its
  default `True` so both the real output and `caplog`'s test capture
  keep working side by side.

  Verified end-to-end against two real running servers: made one real
  page request through `apps/web` to `apps/api` and grepped the same
  `request_id` out of both services' real log output, not asserted
  from unit tests alone. In the process, this same trace caught and
  corrected a real inaccuracy already merged in sprint 49's checkpoint
  entry above and in `apps/web/README.md`/the affected source files'
  docstrings: `generateMetadata`'s `cache()`-wrapped fetch was claimed
  to dedupe with the page body's own call, "confirmed by checking
  apps/api's own request logs" -- logs that did not yet exist at the
  time that claim was written. The real trace showed two distinct
  `request_id`s reaching apps/api for one page view; `apps/api`'s own
  sprint-24 `SnapshotCache` keeps the real cost of the second call low
  (single-digit milliseconds, versus several seconds for the first,
  cold call) regardless, so this is a known, now-honestly-documented
  inefficiency, not a correctness problem -- and a concrete argument
  for why this sprint's tracing is worth having: it caught a false
  claim nothing else in this recovery's process had. Per-source
  (NWS/NOAA CO-OPS/NDBC provider) log lines remain uncorrelated with
  the request trace -- a larger refactor threading the request id
  through every provider call, not attempted here without evidence
  it's worth the churn. `apps/api`: ruff, ruff format, mypy, pytest
  (348 passed) all pass clean. `apps/web`: `npm run lint`/
  `npm run build` both pass clean.
- **Sprint 40, complete (accessibility pass)**: a real `axe-core` sweep
  (`wcag2a`/`wcag2aa`/`wcag22aa` tags) against real running servers
  across every page x 2 viewports (desktop/phone) x 2 color schemes (20
  combinations) -- 0 violations -- plus a second sweep specifically
  covering `LocationSearch`'s interactive dropdown states (open with
  results, open with zero matches), since every earlier per-sprint spot
  check in this recovery only ever loaded a page at rest and never
  exercised this component's own conditional rendering. A scripted
  keyboard-only walkthrough (Tab to the combobox, type a query, Arrow
  through results, Escape, re-open, Enter to select, Tab past it)
  confirmed real focus order, visible focus rings, and no keyboard trap.
  Playwright's `page.accessibility.snapshot()` gives automated
  accessibility-tree evidence -- real names/roles/`disabled` state
  reaching the same platform tree a screen reader consumes -- explicitly
  labeled an automated proxy, not a claim of testing with actual
  screen-reader software, which this sandbox cannot run.

  The interactive sweep caught a real bug: `LocationSearch`'s
  `<input role="combobox">` set `aria-controls` to the listbox's id
  unconditionally, but the listbox `<div>` was only ever rendered when
  there were results -- `aria-valid-attr-value` flagged the dangling
  reference whenever the dropdown was open with zero matches. The first
  fix attempt (only setting `aria-controls` when the listbox was
  rendered) traded that violation for `aria-required-attr`, since ARIA's
  combobox role requires `aria-controls` present at all times -- the two
  rules are only satisfiable together if the listbox element always
  exists. The actual fix: the listbox is now always rendered, with
  visibility toggled via the native `hidden` attribute (the convention
  the ARIA APG combobox pattern itself uses), which also excludes the
  idle, option-less listbox from axe's checks so it never trips
  `aria-required-children`; the "no matches" state now renders a single
  disabled `role="option"` row inside the listbox instead of a sibling
  `<p>`, for the same required-owned-elements reason.

  The full-page sweep's own overflow check (not an axe-core rule --
  axe-core cannot detect WCAG 1.4.10 Reflow automatically) caught a
  second real bug: `ForecastErrorCard`'s troubleshooting paragraph names
  `INTERNAL_SIGNING_KEY_SECRET` inside an inline `<code>`, one long
  unbreakable token that pushed real horizontal overflow past a 390px
  mobile viewport. Fixed with the same `break-words` class already
  applied one line above it in that component.

  The keyboard walkthrough caught a third real bug, unrelated to ARIA
  attributes: `selectResult` sets `query` to the chosen result's full
  name to fill the field, and since that name still meets
  `MIN_QUERY_LENGTH`, it re-triggered the same debounced search effect
  and silently reopened the dropdown (`aria-expanded` flipping back to
  `true` on its own) about 300ms after a keyboard selection, with no
  further user action. Fixed with a ref flag that skips exactly one
  search-effect run when the query change came from a selection rather
  than an edit.

  Verified against two real running servers (`apps/api` on 8000,
  `apps/web` built with `npm run build`/started with `npm run start`,
  signed with the real dev `INTERNAL_SIGNING_KEY_ID`/`_SECRET` pair so
  `LocationSearch` returned real results, not the generic error state --
  an earlier verification pass in this same sprint had missed this and
  nearly axe-checked the error state under both "with results" and
  "no results" labels). `apps/api`: unaffected, no changes this sprint;
  348 tests still pass. `apps/web`: `npm run lint`/`npm run build` both
  pass clean, no new warnings.
- **Sprint 39, complete (responsive polish)**: the Lighthouse/assets
  sub-item was already done (see the sprint-39 row); this closes the
  three remaining items with real measurements, no code changes needed
  since all three were already clean. Layout shift: real Cumulative
  Layout Shift via the browser's own Layout Instability API
  (`PerformanceObserver`, the same signal Lighthouse itself reads)
  across every page x 2 viewports, on initial load and through
  `LocationSearch`'s open/select interaction -- 0.0000 everywhere, since
  the dropdown's `position: absolute` popup never reflows surrounding
  content. Tap targets: axe-core's `target-size` rule is tagged
  `wcag22aa` but ships *disabled by default* -- sprint 40's tag-based
  sweep (`runOnly: {type: 'tag', ...}`) silently skipped it despite the
  tag match, a gap only caught by inspecting the rule's own `enabled`
  flag in `axe.min.js` directly, not by trusting the sweep's "0
  violations" result to mean full WCAG 2.2 AA coverage. Ran it
  explicitly enabled (`runOnly: {type: 'rule', values: ['target-size']}`)
  across every page x 2 viewports -- 0 violations -- cross-checked
  independently with a manual Playwright `boundingBox()` measurement of
  every real interactive element (`button`, `a[href]`, `input`,
  `summary`, `[role="option"]`, `[role="combobox"]`,
  `[tabindex]:not([tabindex="-1"])`, including the search dropdown's
  open options) against the WCAG 2.5.8 24x24 CSS px minimum -- 0
  undersized. (The degraded forecast page genuinely has zero interactive
  elements in its current state -- no `<details>`/`<summary>` renders
  when the score is unavailable -- confirmed as real page content, not a
  selector gap, before trusting the "0 checked" result.) Screenshot
  budgets: this ledger phrase has no prior definition anywhere in the
  repo (checked docs and the legacy `/v2` reference) -- interpreted
  conservatively and documented as such rather than invented broadly: a
  literal full-page-PNG byte-size ceiling (1.5MB) per page x viewport,
  explicitly *not* a full visual-regression CI system, since choosing a
  tool and a baseline-image storage/review workflow is a bigger process
  decision than this pass is authorized to make unilaterally -- flagged
  as a separate open question rather than decided here. All pages
  measured well within budget (29KB-274KB). `apps/api`: unaffected, no
  changes this sprint. `apps/web`: unaffected, no changes this sprint --
  everything already met the bar.
- **Sprint 33, complete (conditions experience)**: the `SourceStatusList`/
  `state` badge work was already done (see the sprint-33 row); this
  closes the sprint by actually demonstrating all four states the
  ledger names. This sandbox's network egress is blocked, so the real
  forecast page's live path has only ever produced `partial`/
  `unavailable` -- `fresh`, `stale`, and a multi-source `degraded`
  fan-out had never actually been rendered or axe-checked, only
  asserted to work from reading the code. Closed with a temporary
  `apps/web/app/preview-sprint33/page.tsx` (same throwaway-mock-preview
  technique as sprints 32/34's tide chart and dashboard hierarchy
  passes) rendering `ForecastCard` four times with hand-built
  `ForecastEnvelope` mocks for `fresh` (all sources ok), `partial` (one
  source degraded, with its raw provider error shown), `stale` (a real
  `warnings` entry surfaced), and `unavailable` (every source down,
  `conditions: null`, a `no_data` warning) -- screenshotted in light and
  dark (confirmed visually: correct badge colors and copy per state,
  provider errors shown only for non-ok sources, warnings rendered only
  when present) and `axe-core`-checked in both themes, zero violations.
  Deleted before this commit -- `git status` confirmed no trace, and a
  fresh `npm run build` confirmed the real route table is unaffected (no
  `/preview-sprint33` route leaked into the build). No bugs found this
  time; no code changes needed beyond the roadmap/README write-up.
- **Sprint 27, complete (design system -- the branding decision)**: the
  product owner directed a full visual rebrand -- a Surfline-style
  outdoor/adventure direction, bright/coastal rather than the darker,
  moodier extreme-sports register Surfline itself often uses, open to
  a new name. A concept canvas (three name directions, a light/dark
  palette, type pairing, and mockups of the home/search/forecast
  screens) was reviewed before any code changed; **"Saltline"** was the
  lead pick and is the name that shipped.

  Implementation, `apps/web` only (`apps/api` untouched): `app/globals.css`'s
  `@theme` tokens carry a new oklch-based coastal palette -- light and
  dark defined separately per token (not a naive light-palette
  inversion), semantic go/marginal/no-go tokens re-tuned per theme --
  plus a Space Grotesk (headlines) / Public Sans (body) type pairing.
  The fonts load via a plain `<link rel="stylesheet">` in
  `app/layout.tsx`, deliberately not `next/font/google`: that API
  fetches the actual font files at *build* time, which fails wherever
  outbound network is restricted, this sandbox included -- a `<link>`
  loads client-side at runtime instead and works identically once
  actually deployed. `next.config.ts`'s CSP gained exactly one
  deliberate external allowance (`style-src`/`font-src` for Google's
  two font hosts) for this, its only exception otherwise being
  self-only.

  `app/components/ui/`'s primitives (`Button`/`Card`/`Badge`/`Field`)
  needed zero code changes -- every real page (home, search, the live
  forecast page with real fanned-out source data) repainted correctly
  from the token change alone, which is exactly the bet sprint 27's own
  "real accessible primitives, not global CSS classes" architecture was
  making. `app/page.tsx` is now a real landing page (hero, three value
  props, links to two real curated locations) instead of sprint 27's
  original component gallery, which moved to `/design-system` rather
  than being deleted. `app/icon.tsx` and `app/opengraph-image.tsx`
  carry the new Saltline logomark -- a horizon line with a sunrise arc
  above it and a wave below, literally the line where tide meets shore.
  Real photography doesn't exist for this product yet, so hero art is
  an explicit, clearly-labeled placeholder pattern (`.ph-photo`/
  `.ph-photo-label` in `globals.css`) naming the real shot that belongs
  there -- never an AI-generated stand-in, per the product owner's own
  instruction on this point.

  Caught and fixed one real bug in the process: `--color-primary` does
  double duty as a button *background* (paired with white text) and as
  bare *text* directly on the page background (`Button`'s "secondary"
  variant, eyebrow labels) -- the initial brighter teal cleared AA
  contrast for the first role but failed the second at 3.6-3.8:1, caught
  by a real `axe-core` sweep, not eyeballing the new palette. Fixed by
  computing actual WCAG contrast ratios (canvas-rendered oklch resolved
  to real sRGB bytes, not estimated) across a range of candidate
  lightness values and picking one that clears 4.5:1 in both roles at
  once, the same dual-role reasoning `--color-danger-text` already
  existed for. Verified end-to-end against two real running servers: a
  full `axe-core` sweep (5 pages x 2 viewports x 2 themes, 0
  violations), the sprint-40 combobox interactive states re-checked
  under the new palette (0 violations), tap-target sizes unaffected,
  and `npm run build`'s route table confirmed correct (`/design-system`
  added, nothing leaked). i18n-ready string externalization (bundled
  into this sprint by R1's disposition) and real photography (needs
  actual shot assets, not attempted here) remain open.
- **Incident (sprint 6, resolved earlier)**: a scratch branch explicitly
  titled `DO NOT MERGE` was merged into `main` under the repo owner's own
  account, landing deliberately-broken code; reverted within ~10 minutes
  in PR #330. Full account in `docs/SPRINT_6_CI_PROOF.md`. Sprint 7
  turned this into a documented branch-hygiene rule.
- **Milestone: Phase 2 (backend) is done.** Sprints 12 through 26 are
  all **Complete** except 13/14/15's remaining deliberately-deferred
  sub-scopes: sprint 13's gridpoint wind fallback and sprint 14's
  CO-OPS wind fallback are both done now (combined into one two-step
  last-resort chain, this PR). What's left of each: sprint 13's
  current-weather observations (air temp/humidity/heat-index/
  precipitation) and sprint 14's currents/environmental-metrics/
  tide-chart SVG remain deferred — no `ForecastConditions` field names
  any of them. NDBC (sprint 15: pressure-trend + fishing-impact
  narrative, both explicitly named as sprint 35's job, not a provider-
  adapter concern) is the one sub-scope not yet touched at all. Phase 3
  (sprints 27+) is entirely `apps/web` frontend/product work and needs
  decisions this session can't make unilaterally: sprint 27 (design
  system) explicitly requires a **branding decision** ("Surf & Pier
  Forecast" is a named placeholder, not a starting-point) before any UI
  work is defensible; sprint 28 (authentication) needs Better Auth +
  Postgres infrastructure decisions neither exist yet. **Update: the
  product owner has directed continuing on regardless** — including
  Phase 3 frontend/visual work — rather than pausing on the branding
  decision; "Surf & Pier Forecast" is used as a working placeholder
  identity throughout, explicitly not treated as final, so Phase 3 work
  can proceed without blocking on a name/visual-identity decision that
  hasn't been made yet. Sprint 15's NDBC pressure-trend/fishing-impact
  work is still explicitly sprint 35's (fishing guidance) per that
  module's own docstring, so it isn't a clean standalone backend pick.
  Sprint 44's signed-internal-API verification primitive (this PR) is a
  fully-specified, non-branding-dependent piece of backend work picked
  up in the meantime. Separately, sprint 9 (preview
  environments) and sprint 10 (production skeleton) need real
  Vercel/Render/Neon accounts this session has no credentials for —
  **flag to the product owner** rather than attempting them blind; they
  can be done whenever those credentials are available, in parallel
  with more Phase 2 sprints.
- Known blocker: sprints 9/10 need Vercel/Render/Neon account access not
  available to this session — needs the product owner to either provision
  and share access, or do that part directly.
- **Resolved**: the legacy `lint` CI job (PRs #347/#348) — no longer
  known baseline debt. `docs/R2_CI_BASELINE.md`'s legacy (repo-root)
  `ruff check`/`ruff format --check`/`mypy` findings (~600 errors, ~65
  unformatted files, 23 mypy errors) are fixed, and the underlying cause
  of the workflow's own CI-vs-local drift — no `pyproject.toml`/`ruff.toml`
  anywhere in the repo, so ruff's rule selection fell back to an
  undocumented, version-dependent implicit default — is fixed too via an
  explicit `select` pin at the repo root (`E4`/`E7`/`E9`/`F`) and a
  separate `apps/api/pyproject.toml` insulating `apps/api` from that
  narrower selection. Both `lint` job runs on PR #348's merge commit show
  `conclusion: success`, confirmed via the GitHub API, not just a local
  check. R1's open product question is still
  unresolved: whether `services/{datagov,hdx_fao,arcgis_live_feeds,
  bathymetry}.py` (not named in the canonical contract's required
  providers) are future enrichment or scope creep — route to the product
  owner before Phase 2 sprints port providers wholesale. This session
  still could not verify GitHub branch-protection/required-status-check
  configuration via available tooling, and separately could not delete a
  git branch via any available tool — a repo admin should handle both,
  including configuring `apps-ci.yml`/`security.yml`'s checks as required
  and deleting `claude/sprint6-ci-failure-proof` (still on the remote,
  merged-and-reverted, safe to delete).
- Unmerged work considered complete: none.
- Product decisions on record 2026-08-17 (see that section above) refine the
  product contract — public general-audience scope, ~$1/month subscription
  intent deferred to sprints 61-63, legacy Flask app retired outright,
  regulations disclaimer + official-source data sourcing requirement,
  export/deletion pulled forward as a v1 requirement, device/browser and
  offline/PWA targets, CAPTCHA-on-registration requirement, in-app feedback
  as a launch requirement, and full (not scaled-back) CI rigor. These refine,
  not reopen, R0's contract and do not change the current gate.

This checkpoint must be updated through a merged PR whenever the active gate
or sprint changes.
